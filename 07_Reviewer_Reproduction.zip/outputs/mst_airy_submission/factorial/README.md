# Crossed perturbations on the R01 recordings

The analysis inputs are archived derived tracks from the parked-vehicle AIRY–ARS408 experiment. Run the script from the portable project's root with Python, NumPy and Matplotlib installed.

```console
python -B outputs/mst_airy_submission/factorial/run_factorial.py
```

`--field` selects the R01 directory containing `replay.py`, the prepared `tracks`, and the original `pairs.csv` and `replay_trials.csv`. `--output` selects the result directory. The default field and results locations follow the archive layout. `--skip-figure` skips the Matplotlib exports.

For every arm and speed rule, the script reads the original pair IDs and checks their reported times, receive times and archived direction labels against the loaded observations. It verifies the pair-schedule hash, common prior epoch and final pair-completion epoch for all four implementations. The clock process settings, covariance and measurement configurations come from the original archived filter configuration. The three axis-model variants use a 0.15 m centre prior standard deviation. Framewise EKF replay consumes exactly the two members of every archived pair in receive order.

The crossing combines no shift and direction-signed shifts of ±8 cm with imposed timestamp increments of −30, 0 and +30 ms. The auxiliary common shifts of ±8 cm use zero timestamp increment. Signed offset change is relative to the unperturbed terminal estimate for the same estimator and pair schedule. Increment recovery subtracts the zero-increment terminal estimate at the same spatial perturbation from the joint-perturbation estimate. Increment error then subtracts the imposed timestamp increment.

`factorial_trials.csv` records the estimates and statuses at the signed condition level, including support, epochs, residual response, posterior diagnostics and counts of valid, failed and downweighted updates. `factorial_summary.csv` and `factorial_summary.json` report absolute summaries and computed denominators. Spatial response averages the two polarities. Nominal increment error averages two timestamp injections, and crossed increment error averages four nonzero spatial and temporal combinations. Figure exports are `figures/factorial_en.png` and `figures/factorial_en.pdf`.

All 264 replays completed, including 168 exact comparisons against the archived single-perturbation and nominal conditions. The other 96 configurations cross a nonzero direction shift with a nonzero timestamp increment. The primary and lower-speed samples comprise 38 and 288 near-constant pairs, 110 and 267 variable-speed pairs, and 49 and 55 pairs in the auxiliary faster interval. They provide six fixed schedules within the two original recordings.

In the illustrative variable-speed primary replay, the original paired EKF gives 28.92 ms at nominal inputs. Direction-signed −8 cm moves the zero-increment baseline to 109.83 ms. The subsequent −30 and +30 ms increments are recovered as −30.21 and +29.82 ms. Direction-signed +8 cm moves the zero-increment baseline to −51.12 ms. The subsequent −30 and +30 ms increments are recovered as −30.92 and +30.56 ms. The average absolute increment error under these four same-displacement comparisons is 0.47 ms. The offsets use the declared AIRY–ARS408 replay time base. The absolute acquisition-time offset remains unknown.
