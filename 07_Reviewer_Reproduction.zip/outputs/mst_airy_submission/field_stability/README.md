# AIRY–ARS408 field sensitivity checks

These checks use the 2–6 m parked-vehicle R01 experiment. The two primary arms contain seven and eight complete traversals. The associated final two faster traversals are outside the current comparison. All fits use the existing AIRY trajectory, the existing spatial transform estimated from the pooled AIRY path, and the fixed direction-and-position matching protocol. Offset candidates are conditional minima under the specified timestamp mapping. The field trial has no independent timing truth or independent identification of each reflector return.

## Reproduce

Run after preparing the R01 derived tracks with `outputs/airy_ars408_vehicle_r01/prepare.py`.

```sh
python -B outputs/mst_airy_submission/field_stability/run_field_stability.py --recordings outputs/airy_ars408_vehicle_r01 --out field_stability_results
```

The script imports the R01 preparation and profile modules from the supplied recordings folder. Their dependencies are the matching historical profile core and `MultiSensor_TimeSync` source. The standalone reviewer bundle preserves these paths. NumPy and Matplotlib are sufficient for this check. The JSON contains both fitted offsets, profile losses, nuisance coefficients, frame counts and matching strata. The alternate radar observations and copied AIRY references are under `alternate_tracks`.

## Frame counts and radar-candidate ranking

The alternative candidate association runs over each complete bag using only radar positions, RCS values, and recorder epochs. A dynamic programme links one eligible candidate per nonempty frame. Eligibility uses a fixed longitudinal interval of 1.75–6.35 m and a lateral corridor of ±0.48 m around the radar axis. The emission penalty is the RCS deficit relative to the strongest eligible candidate at that frame, scaled by 6 dB and capped at three units. It adds a lateral penalty of 0.25 times squared lateral position in units of corridor half-width. When no eligible candidate reports a finite RCS, the RCS term vanishes. The transition penalty sums squared candidate-to-candidate displacement after dividing by 0.20 m plus 1.50 m/s times the elapsed recorder interval for the longitudinal component, and 0.20 m plus 0.50 m/s times the interval for the lateral component. A transition can restart for eight penalty units. Gaps greater than 0.50 s break continuity. The constants use the position granularity and walking-speed scale, without evaluating LiDAR alignment or fitted offset to rank candidate paths. A static clutter path can still compete with the moving target.

The script subsequently extracts the existing LiDAR-derived clip windows and freezes the original LiDAR reference for scoring. The profiler uses the same position bins, time epochs, direction labels and support in both association branches. These coverage counts refer to the fraction of radar frames with a selected candidate, conditional on the recorded and screened candidate field.

| Arm | Native radar frames, complete bag | Native frames, primary clip | LiDAR-gated selections | Radar-only selections | Agreements in selected object ID on shared frames | Agreements in selected XY on the matched schedule |
|---|---:|---:|---:|---:|---:|---:|
| Near-constant | 4,540 | 3,405 | 3,405 | 3,405 | 3,186 of 3,405 | 367 of 409 |
| Variable | 4,712 | 3,194 | 3,191 | 3,194 | 3,017 of 3,191 | 366 of 409 |

The original decimated frame counts are 1,703 and 1,596. The respective fixed-direction and whole-search supports contain 846 and 796 frames. Both arms retain the original 409 per arm in the common-schedule check. At the fixed expansion point, the nominal projected information is identical between association branches because it depends only on the frozen AIRY reference and design. Candidate XY values affect the profile minimum and loss.

| Arm | Model | LiDAR-gated minimum (ms) | Radar-only minimum (ms) | Radar-only minus gated (ms) |
|---|---|---:|---:|---:|
| Near-constant | Geometry | +73.65 | +58.67 | −14.98 |
| Near-constant | Geometry with direction centre | +78.71 | −6.54 | −85.26 |
| Variable | Geometry | +49.90 | +53.31 | +3.42 |
| Variable | Geometry with direction centre | −43.81 | −38.40 | +5.41 |

With independent re-decimation and re-matching of the alternative path, each arm also retains 409 frames. The alternate variable direction-model candidate becomes −38.41 ms. The full JSON separates this branch from the fixed-schedule comparison. Agreement between association rules does not measure object identity or timing accuracy.

## Splits, traversal removal and reference epoch

| Arm | Model | Full cohort candidate (ms) | Alternating 1 s receive bins (ms) | Absolute separation (ms) |
|---|---|---:|---:|---:|
| Near-constant | Geometry | +73.65 | +79.23 / +65.53 | 13.69 |
| Near-constant | Geometry with direction centre | +78.71 | +77.77 / +269.28 | 191.51 |
| Variable | Geometry | +49.90 | +51.55 / +48.03 | 3.53 |
| Variable | Geometry with direction centre | −43.81 | +26.25 / −50.68 | 76.93 |

The splits use alternating 1 s bins relative to the first retained receive epoch, keeping the axis and LiDAR trajectories fixed. Near-constant has 208 and 201 frames, and variable has 215 and 194. The traversal omission removes each trip in either arm in turn, using the recorded endpoints and a 0.65 s margin at each end, and then rematches the two arms. Across the 15 omissions the sample size is 350–394 frames per arm and the variable-to-near direction-model information ratio is 3.39–5.19. Candidate ranges in that model are −124.55 to +136.20 ms and −48.45 to −2.47 ms, respectively. These ranges measure omission sensitivity within the two bags, whose frames share trajectory measurements.

Changing the pooled AIRY anchor from the 5th to the 50th percentile of receive minus device time moves the AIRY timestamps by +6.061161 ms. With the same events, direction labels, axis and translated offset domain, the equivalent reported candidate offset moves by −6.061161 ms. This follows from the reference query at reported time minus fitted offset. On the reported grid and at each fitted minimum, the largest absolute change in total Huber cost was below 2.0 × 10⁻¹⁰ in the local Windows run. The manipulation changes the replay time coordinate and cannot establish the relative physical acquisition times.
