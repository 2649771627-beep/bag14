# Reproduction of the reversal calibration experiments

This companion runs the core identifiability and displacement experiments using numerical target tracks derived from recordings 08 and 09. It includes the input tracks, deterministic selection and pairing, estimator code, archived numerical references and plotting code. The input tracks contain bag-relative times and target coordinates. They contain no raw ROS bags, images, absolute recording timestamps or local filesystem paths.

## Run the experiments

Use Python 3.12 and install the provided dependencies in a virtual environment. NumPy is required for the numerical checks. Matplotlib is needed only to regenerate the figures.

```console
python -m venv .venv
# Activate the environment using the command for your shell.
python -m pip install -r requirements.txt
python reproduce.py --output reproduced_results --figures
```

Choose a new output directory on each run. Omit `--figures` for a numerical-only run. A successful run ends with `All comparisons passed`. There is no ROS dependency or network access during the replay. The numerical and figure checks used Python 3.12, NumPy 2.3.5 and Matplotlib 3.11.2. The numerical checks allow small floating-point differences across builds. Do not use Python's `-O` flag because the checks use assertions.

| Manuscript evidence | Files written under the output directory | Scope |
| --- | --- | --- |
| Scalar mechanism with known timing truth (Table 1) | `independent_theory_results.json`, `independent_theory_trials.csv`, `independent_theory_summary.txt` | Regenerated for four motion designs, 1,000 trials per design. Checks identifiability, acceptance counts and absolute RMSE on accepted trials. |
| Matched speed comparison and whole-support 09 check (§4.7 in the working draft) | `table_profile.csv`, `comparison.json`, `cost_profiles.png` | Regenerates target trajectory interpolation, observation selection, direction and position matching, profile costs, local information and validity decisions. Checks the exact event sets and numerical agreement with the archive. |
| Fixed-pair perturbations (§4.8 in the working draft) | `table_pair.csv`, `pair_endpoints.csv`, `experiment.json`, `offset_response.png` | Rebuilds the fixed 36/13 pairs and reruns all EKFs for five spatial conditions, each with zero and ±30 ms timestamp shift. Checks all 2,205 estimator-by-condition endpoint values. |
| Broader observation, filter and transfer evidence (working-draft Tables 2–4; recorded validity coverage) | `archive/supporting_results.json` (included) | Manuscript table transcription and recorded diagnostic dispositions for inspection. The full camera and radar extraction pipeline, older multirecording analyses and trajectory-driven sensor simulation are outside this executable package. |

## What the inputs represent

`inputs/recording_08.json` and `inputs/recording_09.json` provide the revised LiDAR and radar tracks in the nominal C16 LiDAR coordinate frame. Radar receive times are integer nanoseconds from the first bag record (the field `bag_record_ns` is relative in this package). The `t` values are the original header times expressed in seconds from that same origin. `row_id` is the row number in the original revised radar track array. `event_identity.json` freezes the selected radar row indices, event-index pairs, reference direction axes and labels, and the archived nominal same-member estimates. The replays regenerate the event and pair identities from the supplied tracks and compare them against the frozen list. Table and figure calculations start after target extraction.

The fixed reference uses the original LiDAR track rows, smoothing half-window of 0.45 s and interpolation gaps of at most 0.35 s. Reference queries subtract the estimated radar offset from radar header time. Receive times order and propagate the filter states. No independently measured clock offset exists for the recorded bags. The original source checksums in `inputs/manifest.json` identify the author-held revised track files. Separate package checksums verify the compact input files and runnable code. Publication or release of author-held raw recordings is outside this package.

## Expected checks and interpretation

The matched 08 groups have 64 events apiece. With the direction center included, nominal projected information rises from about 77.9 to 228.0 s⁻², and the block-inflated diagnostic falls from 171.1 to 102.0 ms. The 09 whole-support check uses 79 events and yields 100.7 ms with the direction term. These three fits are withheld by the original diagnostic policy. The corresponding geometry-only fits pass that policy. Recording 09 is a retrospective reproduction using the same already examined recording.

The fixed-pair replay evaluates 36 endpoints in 08 (33.042–71.958 s) and 13 in 09 (35.158–57.633 s). Each recording uses the same initial state and covariance at its earliest pair member (27.594 s for 08 and 33.755 s for 09) for the difference and framewise EKFs. The framewise estimate using only completed pairs is reconstructed from the same prior using those members in receive order. Each displacement condition uses both 8 cm polarities along the frozen motion axis. A common shift cancels to floating-point precision in the difference EKF. The direction-dependent shift changes its estimated offset by 99.26 ms RMS in 08 and 84.59 ms RMS in 09. The direction-dependent case is an artificial modification of recorded observations. It tests the response to a specified center displacement of each radar observation. The ±30 ms recovery metric subtracts the no-injection estimate at the same displacement, so any shared baseline error cancels. The recorded diagnostic limits and all endpoint contrasts are conditional on the reference and model.

The separate scalar simulation imposes a known 30 ms offset and 8 cm direction center term. The full model withholds both constant-per-direction designs and accepts the two designs with within-direction speed variation. Its reported error is relative to the generating offset and applies to the simulated model only.
