# Own08/09 target-epoch reproduction bundle

Run from this folder using Python3.11+ and NumPy. No bag, video, H5 parser, ROS installation, original workspace, or network connection is needed. Matplotlib is optional.

```text
python run.py --output replayed_results
python run.py --output full_matrix_results --matrix --figures
python run.py --check-only
```

Choose a fresh output directory. The default replays the original36/13 frozen-pair nominal comparisons, the35/14 newly selected pairsets, the18/7 identical-pair intersections, both shared-support profiles, and the corrected-time native-support profiles. `--matrix` adds all5space×3time conditions on the identical-pair intersections. Saved golden outputs are checked during each run.

The epoch adapter regenerates `t_target=t_header+median(point.time)` from exported per-cluster timing metadata. It preserves every position and radar observation. The archived C16 driver describes seconds relative to scan-start capture time; that clock is HostEstimated. The adapter does not deskew points or establish absolute hardware clock truth.

## Observation sets must not be conflated

|Set|08|09|
|---|---:|---:|
|Unchanged candidate selection under either epoch convention|197|114|
|Original header-time full profile support|176|79|
|Earlier08 near-constant / variable matched subgroups|64each|not applicable|
|Fair intersection of full support under both epochs|175|77|
|New target-epoch native full support|178|77|
|Original / reselected pairs|36/35|13/14|
|Identical raw-row pairs selected by both rules|18|7|

The fair profiles freeze the original LiDAR principal axis and the original-reference velocity sign, then require every retained observation to satisfy the same full-search support and sign/speed rules under both references. A175-event comparison is not the earlier64-event subgroup experiment. All excluded raw rows and their reasons are included in the saved preparation manifest.

The default reports the same prior and terminal within each explicit comparison. In the reselection audit, a branch ending early is propagated to the shared terminal with the unchanged constant-drift transition; it receives no extra measurement. An estimated `b=47.49ms` is not a pass of the50ms gate: the latter concerns an identifiability diagnostic, and direction-centre profiles remain rejected.

## Files and provenance

- `core/`: exact archived compact reviewer reproduction code and original compact trajectory observations; its original manifest is checked.
- `code/`: portable helper functions derived from the executed epoch branches and the explicit epoch adapter snapshot.
- `inputs/`: exported original cluster timing metadata, adapter-produced corrected trajectories, source hashes and saved comparison outputs.
- `evidence/`: driver-semantics and adapter validation records; no raw video or full bag.
- `manifest.json`: hashes of all packaged static files and project-relative source mappings. Absolute machine paths are not runtime dependencies.

These are private author-supplied derived trajectories and code for local review. No public upload or publication has been performed. Any later public data release requires the author's intended release terms and appropriate source attribution. Innovation2 and the original50ms policy are unchanged.
