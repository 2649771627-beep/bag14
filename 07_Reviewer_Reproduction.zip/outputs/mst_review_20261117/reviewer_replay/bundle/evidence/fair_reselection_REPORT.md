# 新时刻规则重选与共同观测公平对照

原36/13固定回放保留在上一级。这里同时保留新原规则pair集以及两次原规则输出完全相同的pair交集；两个时刻解释始终使用相同prior和共享终点。所有profile公平对照先冻结共同候选行、共同全域支持、旧轴和方向，再拟合。

集合口径：旧08近恒速/变速对照各64个event，是从原197个候选中、原176个完整支持event内配平得到的两个子组。新175是两参考完整支持的公平交集，并不是旧64个子组；不能把两者当成同观测结果。旧09完整支持79个event，新公平交集77个。这里的轴冻结为旧event_identity.json记录的LiDAR主轴，方向固定为旧参考在共同候选时刻上的轴向速度符号；每个保留event在两参考的完整搜索域都复核同号且满足0.10 m/s条件。

|录制|集合|pair数|方法|header终点(ms)|point终点(ms)|变化(ms)|
|---|---|---:|---|---:|---:|---:|
|08|old_frozen|36|raw_stream|177.936|149.515|-28.421|
|08|old_frozen|36|difference|187.920|160.033|-27.887|
|08|old_frozen|36|raw_completed_pairs|177.936|149.515|-28.421|
|08|new_original_rules|35|raw_stream|169.387|141.317|-28.070|
|08|new_original_rules|35|difference|178.604|150.574|-28.030|
|08|new_original_rules|35|raw_completed_pairs|169.387|141.317|-28.070|
|08|identical_pair_intersection|18|raw_stream|179.031|153.613|-25.417|
|08|identical_pair_intersection|18|difference|181.883|156.891|-24.993|
|08|identical_pair_intersection|18|raw_completed_pairs|179.031|153.613|-25.417|
|09|old_frozen|13|raw_stream|92.922|71.389|-21.533|
|09|old_frozen|13|difference|94.092|72.846|-21.246|
|09|old_frozen|13|raw_completed_pairs|92.922|71.389|-21.533|
|09|new_original_rules|14|raw_stream|99.461|78.167|-21.294|
|09|new_original_rules|14|difference|99.396|78.103|-21.293|
|09|new_original_rules|14|raw_completed_pairs|99.461|78.167|-21.294|
|09|identical_pair_intersection|7|raw_stream|63.676|47.262|-16.414|
|09|identical_pair_intersection|7|difference|63.713|47.491|-16.222|
|09|identical_pair_intersection|7|raw_completed_pairs|63.676|47.262|-16.414|

|录制|profile支持|时刻解释|模型|n|b(ms)|工程尺度(ms)|接受|原因|
|---|---|---|---|---:|---:|---:|---|---|
|08|fair_common|header_epoch|geometry|175|129.841|25.260|True||
|08|fair_common|header_epoch|direction|175|-3.281|117.944|False|weak_temporal_information|
|08|fair_common|target_point_epoch|geometry|175|105.214|25.197|True||
|08|fair_common|target_point_epoch|direction|175|-26.630|118.606|False|weak_temporal_information|
|08|new_native|target_point_epoch|geometry|178|104.960|24.532|True||
|08|new_native|target_point_epoch|direction|178|-22.105|114.279|False|weak_temporal_information|
|09|fair_common|header_epoch|geometry|77|128.291|27.593|True||
|09|fair_common|header_epoch|direction|77|102.327|104.416|False|weak_temporal_information|
|09|fair_common|target_point_epoch|geometry|77|104.431|27.593|True||
|09|fair_common|target_point_epoch|direction|77|84.853|104.600|False|weak_temporal_information|
|09|new_native|target_point_epoch|geometry|77|104.431|27.593|True||
|09|new_native|target_point_epoch|direction|77|84.073|104.592|False|weak_temporal_information|

08: 原候选197，新候选197，共同候选197；共同完整支持175。仅header候选行[]；仅point候选行[]。完整逐行选择/支持原因见protocol.json。

09: 原候选114，新候选114，共同候选114；共同完整支持77。仅header候选行[]；仅point候选行[]。完整逐行选择/支持原因见protocol.json。

不同pair集合的观测数本来不同，不能把其终点差全部解释为时间修正效果；主要公平比较是同一集合内header与point两参考，以及同样event集合的两profile。对末次更新早于共享终点的分支，只按原常漂移转移公式预测offset，没有新增观测或给出该终点的新协方差声明。

严格共同pair集的±8 cm与±30 ms全部结果保留在JSON和response_summary.json；共同位移抵消、方向扰动与注入恢复仍是模型/数字响应检查，不提供绝对硬件时差真值。

09共同pair终点b=47.491 ms不表示通过50 ms门槛：b是未知相对时差的估计值，门槛约束的是可辨识性工程尺度；带方向中心的公平profile仍为104.600 ms并拒绝。
