# Own08/09 C16 timestamp audit

Executed2026-11-16. Original bags were opened read-only. No source video/image was read or exported, and no original trajectory, timestamp or result was modified. `raw_audit.json` stores raw-message schemas, header matches, source hashes and examples; `cluster_reconstruction.json` stores recovered native target-point indices and independent reconstruction checks.

## Verified directly from the recordings

| Property |08|09|
|---|---:|---:|
| Raw C16 PointCloud2 messages |880|718|
| Retained target trajectory rows |835|699|
| Retained timestamp mismatches against raw headers |0|0|
| Target median point offset, minimum (ms) |8.773|9.080|
| Target median point offset, median (ms) |24.118|19.777|
| Target median point offset, maximum (ms) |38.590|38.101|
| Target median point offset, SD (ms) |8.564|8.187|
| Raw clouds inspected in full |9|9|
| Points in these nine clouds |261,446|261,378|
| Non-finite time values in these clouds |0|0|
| Zero point-time values in these clouds |9|9|
| Independently reconstructed target-cluster points |2,282|2,290|
| Largest sampled target-cluster time span (ms) |3.301|3.102|

Each cloud has point_step22 bytes with x/y/z/intensity FLOAT32 at offsets0/4/8/12, ring UINT16 at offset16, and time FLOAT32 at offset18. The inspected time values run from0 to approximately0.100037; all rings0–15 occur. The zero-time rate is approximately0.00344% in the inspected clouds: one point per frame. None of the recovered target points has zero time. All835/699 cached target median times are finite and nonzero.

The 18 target clusters were selected by evenly spaced indices before this audit. The original ROI, three-second background rule, connected components and cluster ranking were reconstructed from raw data. Native PointCloud2 indices are stored before finite-point, ROI or background filtering. The reconstructed coordinatewise XYZ medians, time medians and point counts match the cached rows exactly. Original float32 arithmetic was preserved; introducing a float64 index column into median computations would otherwise change last-bit rounding.

The compact reviewer inputs' entire835/699 LiDAR rows also match the full source trajectories for all shared fields. Therefore their retained quality medians can be joined by unchanged row identity; a fresh association is unnecessary for a timestamp-convention comparison.

## Timestamp semantics and strength of evidence

The archived08/09 setup files both select the custom `c16_legacy_udp` driver. The20261107 source extracts contain direct code evidence:

- `车载传感器采集_20261107/车端版本与时间戳源码摘录.txt`, lines161–170: `kHostEstimated=3`; the point offset is documented as relative to `capture_time_ns`, in seconds; the C16 decoder sets `capture_time_ns=point_ns` at frame start and computes `(point_ns-frame.capture_time_ns)/1e9`.
- `车载传感器采集_20261107/三路驱动时钟源码摘录.txt`, lines78–89: a relative device tick is anchored to `receive.time_ns`; packet time advances by device elapsed microseconds. Divergence can reset the anchor. This is an estimated host-epoch mapping, not an independently synchronized hardware clock.
- The contemporaneous `车载传感器采集_20261107/采集报告.txt`, line56, explicitly records the point-cloud header as the estimated scan-start point time and the point time as a relative second offset. The report also records online `time_quality=3`.

This supports interpreting the recorded `time` field as a relative firing-time offset in seconds and motivates a **source-supported timestamp-convention correction branch**. A complete ROS publisher source and deployed-binary hash chain for the later08/09 recordings has not been preserved in these evidence files. That remaining provenance limit should be stated; the excerpts and contemporaneous observation are not an independent clock truth.

The ARS408 counterpart also uses host-estimated time: the archived decoder note specifies the0x60A cycle-boundary receipt, not the hardware target-sampling instant (`三路驱动时钟源码摘录.txt`, line98; contemporaneous report line57). No absolute cross-sensor hardware offset can be recovered solely from these metadata.

Raw bag-arrival minus LiDAR-header differences are recorded as diagnostics only. They were **not** used to infer whether the header means scan start, midpoint or end, or to estimate physical clock offset.

## What the original experiment actually used

`MultiSensor_TimeSync/src/data_loader/lidar_radar_targets.py`, lines192 and229–237, reads the native point time and retains its selected-cluster median as `quality.point_time_field_median_raw`. But the trajectory time is assigned as `(header_ns-epoch_ns)*1e-9` at line231. Every retained row matches this header-only convention in the raw bag. The point-time median was preserved as metadata and **not applied to the reference trajectory timestamps**.

A new branch can retain the same XYZ observations and assign `t_target=t_header+median(point_time)` according to the archived driver semantics. Keep the original header and median in separate columns, preserve the old branch, and revalidate frozen pair support/distance/direction conditions after rebuilding the reference. Do not re-pair to hide failures.

For a uniform added reference shiftδ, the model `p_L(t_r-b)` requires `b_new=b_old−δ`; this gives a sign check only. Here the offsets vary with target observation geometry, so simply subtracting their median from the final estimate is not equivalent to rebuilding and replaying the trajectory.

The cluster median time is a practical representative epoch. Coordinatewise XYZ medians need not arise from the same physical point or exactly that time, and the inspected target points span up to3.3ms. No motion deskew or rigid-target truth has been supplied. This branch corrects a documented reference-time convention while retaining those geometric and temporal approximation limits.

## Implication for the50ms diagnostic

The original50ms quantity was computed conditional on a header-time, fixed LiDAR trajectory. It does not bound an omitted scan-phase convention, host-epoch mapping delay, target-dependent scattering offset or absolute sensor-clock error. The observed9–39ms target-point offsets are systematic reference-model terms, not estimates of the diagnostic's statistical uncertainty. Changing the reference convention may move fitted offsets even when injected±30ms increments still recover well.

The correction replay is assigned to the separate `joint_position_doppler/own_point_time_correction/` worker. This audit itself makes no corrected-result or acceptance claim. Innovation2 remains untouched.
