# 目标点时刻分支核验

核验通过：原header分支的全部三估计器终点与归档offset一致；新共同支持逐行相同、时间块相同；共同pair恰为两原规则输出交集且两时刻解释均满足原配对条件；共享终点的常漂移预测公式逐值一致；原始文件哈希不变。

对每源共同pair集的两时刻解释重新独立回放nominal，所有终点offset与保存结果一致。所有共同±8 cm扰动下差分EKF的完整时序抵消也检查通过。

- 08: `{"original_all_estimators_archive_max_offset_error_s": 1.3156142841808105e-14, "identical_pair_intersection_verified": 18, "fair_profile_rows_verified": 175, "same_time_blocks_verified": true, "shared_terminal_transition_max_error_s": 0.0, "all_common_displacement_difference_max_error_s": 0.0, "independently_replayed_nominal_common_pair_max_error_s": 0.0, "all_reference_failures": {"old_frozen": {"header_epoch": [], "target_point_epoch": []}, "new_original_rules": {"header_epoch": [], "target_point_epoch": []}, "identical_pair_intersection": {"header_epoch": [], "target_point_epoch": []}}}`
- 09: `{"original_all_estimators_archive_max_offset_error_s": 6.661338147750939e-16, "identical_pair_intersection_verified": 7, "fair_profile_rows_verified": 77, "same_time_blocks_verified": true, "shared_terminal_transition_max_error_s": 0.0, "all_common_displacement_difference_max_error_s": 5.689893001203927e-16, "independently_replayed_nominal_common_pair_max_error_s": 0.0, "all_reference_failures": {"old_frozen": {"header_epoch": [], "target_point_epoch": []}, "new_original_rules": {"header_epoch": [], "target_point_epoch": []}, "identical_pair_intersection": {"header_epoch": [], "target_point_epoch": []}}}`

raw_cluster重建证据：outputs\research_extension_20261116\reference_consistency_audit\own_clock_audit\cluster_reconstruction.json

目标点时间中位数是对选中簇的时刻代表值，不是逐坐标中位数严格共享的物理采样时刻，也没有实施逐点运动补偿。抽检目标簇内点时间跨度最大约3.3 ms；完整录制二进制到归档源码链仍不完备，HostEstimated接收锚定时钟也不提供绝对真值。

09共同pair终点b≈47.49 ms不是通过50 ms门槛：b是未知相对偏移估计，门槛约束位置profile的可辨识性工程尺度；带方向中心的公平共同profile仍约104.60 ms并拒绝。
