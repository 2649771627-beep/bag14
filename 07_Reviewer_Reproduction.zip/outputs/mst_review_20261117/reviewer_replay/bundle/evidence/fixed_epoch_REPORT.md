# 自有08/09目标点时刻修正分支

只把LiDAR轨迹时刻从帧header改为header加原选中目标簇的point.time中位值，坐标和雷达观测不变。这是归档驱动语义下的时刻解释修正/敏感性，不是独立物理时钟标定；原结果及50 ms数值保留。

|录制|原固定pair数|修正后仍满足原配对条件|方法|原终点b(ms)|修正终点b(ms)|变化(ms)|
|---|---:|---:|---|---:|---:|---:|
|08|36|29|raw_stream|177.7544|149.3504|-28.4039|
|08|36|29|difference|187.7494|159.8781|-27.8712|
|08|36|29|raw_completed_pairs|177.7544|149.3504|-28.4039|
|09|13|12|raw_stream|93.0033|71.4531|-21.5502|
|09|13|12|difference|94.2065|72.9432|-21.2633|
|09|13|12|raw_completed_pairs|93.0033|71.4531|-21.5502|

固定pair回放即使原配对条件发生变化也完整保留，视为时刻敏感性诊断；失去资格的pair没有从分母移除，也没有默默重配。重新按原规则可得到的pair数单列，暂未用其滤波结果替代上述对照。

|组|时刻解释|模型|b(ms)|原工程尺度(ms)|接受|原因|
|---|---|---|---:|---:|---|---|
|08_full|header_epoch|geometry|131.237|24.863|True||
|08_full|header_epoch|direction|-3.655|115.822|False|weak_temporal_information|
|08_full|target_point_epoch|全部|—|—|未评价|完整搜索支持/方向发生变化|
|08_near_constant|header_epoch|geometry|126.315|27.631|True||
|08_near_constant|header_epoch|direction|10.713|171.142|False|weak_temporal_information, split_instability|
|08_near_constant|target_point_epoch|全部|—|—|未评价|完整搜索支持/方向发生变化|
|08_variable|header_epoch|geometry|148.563|25.799|True||
|08_variable|header_epoch|direction|-76.518|101.971|False|weak_temporal_information, split_instability|
|08_variable|target_point_epoch|geometry|123.251|25.751|True||
|08_variable|target_point_epoch|direction|-101.662|101.831|False|weak_temporal_information, split_instability|
|09_full|header_epoch|geometry|129.059|27.227|True||
|09_full|header_epoch|direction|112.174|100.731|False|weak_temporal_information|
|09_full|target_point_epoch|全部|—|—|未评价|完整搜索支持/方向发生变化|

08: point.time偏移分位0/10/50/90/100%= [8.773179724812508, 10.671935975551605, 24.11798946559429, 35.67369803786278, 38.590140640735626] ms；原始LiDAR835行XYZ和compact输入逐行完全相同。按不变原规则重新选择/配对可得35对（独立审计，不替换固定对照）。

09: point.time偏移分位0/10/50/90/100%= [9.079593233764172, 10.06934605538845, 19.777359440922737, 31.958340108394623, 38.10114413499832] ms；原始LiDAR699行XYZ和compact输入逐行完全相同。按不变原规则重新选择/配对可得14对（独立审计，不替换固定对照）。

输入文件哈希未改变；header分支逐个原逐帧滤波状态与归档结果核验。初始prior和所有比较终点相同。完整参考失败、原pair每项距离/速度/余弦条件、所有终点状态、代价曲线和拒绝原因均在JSON保留。

接收机锚定的HostEstimated时钟、未知的录制二进制与归档源码完整对应链，均限制物理解释；不能把本修正后的b当成已知真实硬件时差。
