# LiDAR–radar timing reviewer replay

This supplement contains the derived LiDAR and radar target tracks used in the in-house 08 and 09 results, frozen observation identities, model configurations, and the synthetic known-clock study. The primary review comparison uses fixed sets of 36 and 13 pairs under both the header-time and target-point-time reference conventions. An eligibility sensitivity analysis uses intersecting sets of 18 and 7 pairs. The recorded location perturbations are applied numerically to observed trajectories.

## Run

Extract the archive and run in this directory with Python 3.11 or later and NumPy. The reference validation used Python 3.12.14 and NumPy 2.3.5. No ROS installation, raw bag, video, private workspace, or network access is needed once dependencies are installed. All programs operate on the packaged inputs. Output paths below stay inside the extracted copy.

```text
python -m pip install -r requirements.txt
python run_replay.py
python simulation/run_known_truth.py
python simulation/verify_terminal_affine.py
python simulation/check_gain.py simulation/signed_endpoint_errors_ms.npz
python verify.py
```

- `run_replay.py` regenerates the eight recorded groups across both epoch conventions, using five spatial perturbations and three injected timestamp values. Its outputs include all 4,440 main endpoint rows and the reference support/eligibility checks.
- `simulation/run_known_truth.py` reruns 500 noise trials for each of the two motion designs with a true +30 ms offset and the frozen production settings. The three static fits and the two EKFs use matched inputs.
- `simulation/verify_terminal_affine.py` independently probes the terminal weights on the simulated straight legs, reconstructs the signed errors, and writes the affine noise prediction.
- `simulation/check_gain.py` recomputes the polarity-pooled percentage reduction and its paired-trial bootstrap interval.
- `verify.py` compares the regenerated endpoint rows, summary, Monte Carlo outputs, affine results and pooled reduction with the snapshots in `expected/`. Internal absolute file paths and source provenance labels are outside this numerical comparison.

For the original 08/09 profile and reference-epoch comparisons, proceed with the entry points from the packaged input archive:

```text
python bundle/run.py --check-only
python bundle/run.py --output replayed_08_09_profiles
python bundle/core/reproduce.py --output reproduced_header_profiles
```

`bundle/run.py` regenerates the common-support and target-epoch-native profiles under the original policy. `bundle/core/reproduce.py` regenerates the older 08 matched-speed groups and 09 original full-profile replay. The numerical threshold remains 50 ms for the offline conditional scale. The recorded displacement response, simulated terminal RMSE, and timestamp-increment recovery are separate metrics.

## Materials and scope

- `bundle/` derives from the archived compact 08/09 package. Its input manifest, source map and sensor-timestamp audit are included. Machine-specific prefixes were removed from provenance labels and their corresponding checksums were updated.
- `expected/` stores the review-version numerical references. `VALIDATION.json` reports the independent copy check.
- The package covers the in-house replay, the profile comparisons in the bundled entry points, and the synthetic controls. The public Radar Ghost data experiments use their separate reproduction materials.
- The in-house sensor trajectories and processing code are prepared for review. The original author-only footage and ROS recordings are outside the release. The native relative acquisition delay has no independent physical timing witness in these recordings.
