# Portable LiDAR–radar timing reviewer replay

This archive supplies the numerical inputs, code and expected results for the revised paper on timing identifiability in opposite-direction LiDAR–radar calibration. It is suitable for offline review from extracted trajectories and candidate returns. The AIRY field recordings contain no independently measured acquisition-time offset. The synthetic experiments have artificial clock offsets used only to score those experiments.

## Run from a clean directory

Use Python 3.12 and the pinned versions below. Dependencies may be installed from ordinary Python wheels. Once installed, the replay needs no network, ROS or project checkout. The renderer uses bundled Matplotlib fonts.

```text
python -m pip install -r requirements.txt
python -B run_all.py --workers 6
```

The single entry point verifies the archive SHA-256 ledger, regenerates the AIRY tables and plots, Supplementary Analyses S1–S3 and the Radar Ghost evidence in S4, then compares the numerical outputs with the frozen references. It writes under `generated/` and preserves the archived inputs. `--workers 1` gives a single-worker simulation. `--reuse-simulation` uses archived synthetic trials, then recomputes the summaries and scale audit. `--skip-legacy` uses the archived 08/09 and known-clock artifacts while recomputing the current replays.

See the [current English supplement, S1–S10](Supplementary_Analysis.md) and the [archived Chinese reading copy](Supplementary_Analysis_ZH.md). The [publication index](PUBLICATION_INDEX.csv) maps the current labels to evidence and gives earlier labels for reference. Stable script and output filenames are retained.

To reproduce the new manuscript section without running the older or synthetic experiments, use:

```text
python -B run_all.py --point-timing-only
```

This verifies the input ledger, re-prepares the derived field tracks and then reforms the same fixed-pair reference using AIRY board-point time. It checks the reported epoch, direction label, pair ID, prior and terminal receive epoch against the frozen pairing schedule. It writes numeric and graphical outputs to `generated/point_timing/` and checks every value in the four numeric replay outputs against the archived reference with documented tolerances. The default renders the English submission figures with Matplotlib's bundled DejaVu Sans. To render the Chinese reading-copy figures as well, pass `--cjk-font` followed by a path to a local Chinese TrueType or OpenType font. The office copy used Microsoft YaHei. The verification report records image dimensions and PNG fingerprints, which can vary with the renderer or font.

## Table 6 only

```text
python -B run_all.py --table6-only
```

Both this command and the full replay refit eight profiles from derived observations and frozen support rules. The input ledger and the published table precision are checked before writing `generated/table6.csv`. The CSV gives the continuous conditional scale, selected fit flag codes and the English and Chinese display labels. The dagger identifies the public direction fit's out-of-domain scale evaluation.

The selected flags cover solver nonconvergence, profile multimodality, proximity to the search boundary, low retained timing information fraction, residual mismatch, out-of-domain geometry or centre bias, invalid projection linearization, motion-axis or reversal support, and insufficient or unstable alternate-bin splits. `None` means that none of these checks raised a flag. The 09 direction fit reports `None` with a continuous scale of 100.731 ms. The reporting column does not classify any fit using a scale cutoff, and the scale describes model-conditioned sensitivity. The historic solver and its diagnostic outputs remain archived for the older replay checks.

## Radar Ghost supplement only

```text
python -B run_public_evidence.py --output generated/public_evidence
```

This recounts the three sampling policies from archived nonreused pair indices, checks the G01-C/left Table 8 response metrics from archived EKF endpoint outputs and redraws Figures S3–S4. The two G01-C/left method rows in the output CSV supply the paired and framewise cells of the single manuscript row. The replay begins at frozen evidence, as detailed in [DATA_SOURCES.md](DATA_SOURCES.md). Chart fingerprints are recorded for comparison across environments.

## Additional supplementary evidence

- Analysis S5, Figures S5–S6, and Analysis S10, Figure S11, use the [added figure data and scripts](added_figures/README.md). The scripts run from archived numeric inputs. The speed terms can also be re-exported from a clean replay.
- Analysis S6 provides the full methods, derivations and implementation details.
- Analyses S7–S8 supply the archived reference-window, clock and dependence analyses. See [the archived evidence index](archived_sensitivity/README.md) for the CSV and JSON results behind Tables S6–S8 and Figures S7–S8.
- Analysis S9 pairs Figure S9 with the generated shared-displacement control and Figure S10 with the archived same-point ablation.

Standalone figure PNGs are supplied under `figures/`. The three added vector PDFs are under `added_figures/figures/`. The supplementary snapshot and publication index follow the current numbering.

## Evidence index

| Manuscript item | Inputs and outputs |
|---|---|
| Table 5, G18-C/right | Pair counts for the full public profile example, regenerated in `generated/public_evidence/table5_public.csv`. |
| Table 6 | Eight refitted profiles with continuous scales and selected flags in `generated/table6.csv`. |
| Table 8, G01-C/left | The fixed 14-pair comparison is summarized in one manuscript row. The two method records and curves are in `generated/public_evidence/`. |
| Supplementary Analysis S4, Table S5, and Figs. S3–S4 | The four low-support streams are consolidated in `generated/public_evidence/table_s5.csv`. The two G01-C/left figures are redrawn in the same directory. Archived submission images are in `figures/`. |
| Table 11 and Figure 6 | Seed-level trials, all 30 seeds in each of two motion profiles, two known timing offsets, four observation cases and four filters. Full run regenerates 1920 trials and their pair-schedule hashes. See `generated/simulation/`. |
| Table 12 and Figures 7–8 | Two exported AIRY–ARS408 recordings, nominal geometry and original radar association settings, prepared clips and matched profile supports. The reported profile results are continuous conditional sensitivity and candidate offsets. See `generated/field/`. |
| Table 13 and Figure 9 | Archived fixed-pair spatial and temporal perturbations. The nonrobust direction-centre control is included with both pairing-speed rules in `generated/field/replay_summary.json`. |
| Table 14 | Alternate receive-time block fits, leave-one-round-trip-out sensitivity, and alternate radar association using the same raw exported candidates. See `generated/field_stability/`. |
| Figure 10 | Timestamp increments at each displaced baseline, using archived pair membership, priors and completion epochs. See `generated/factorial/`. |
| Table 15 and Figures 11–12 | Fixed-pair timestamp-reference comparison on 38, 110 and 49 pairs. Recreated as `generated/point_timing/table18.csv` and the two `point_timing_*_main_en.png` files in `generated/point_timing/figures/`. |
| Supplementary Analysis S3 | All 24 fixed-pair estimator/clock combinations and 136 round-trip omissions. See `table_s3.csv` and `table_s4.csv` and both `point_timing_*_en.png` figures without `_main_` in the same output tree. These numerical outputs describe timing-reference sensitivity. |
| Figure S9 | Shared-translation simulation and comparison with the archived paired and framewise estimates. See `generated/augmented/`. |
| Figure S10 | Same-point projected-information ablation. The archived numeric artifact under `review-stage/experiments/local_information_ablation/` is the figure input. |
| Section 5.1, diagnostic procedure | Table 13 and Figure 10 supply the fixed-observation comparison. Supplementary Analyses S1–S3 audit pairing support, local scale and the AIRY time convention. |
| Section 5.2 and Table 16, measurement influences | Inputs for the reported sensitivities are under `generated/field/`, `generated/field_stability/` and `generated/factorial/`. |
| Section S1, strict opposite-axis comparison | Removes two same-sign pairs from the 110-pair primary variable-speed schedule, keeps its initial and final receive times, and repeats the crossed perturbations on the remaining 108 pairs. See `generated/diagnostic_supplement/strict_opposite_*.csv`. |
| Section S2, local-scale audit | Selects the continuous-coordinate tracked robust paired estimator records from Table 11. It accounts for all 120 scheduled trials, including one missing estimate, and computes descriptive stratified Spearman correlations from the 119 valid trial records. See `generated/diagnostic_supplement/simulation_scale_*.csv`. |
| Earlier 08/09 and known-clock controls | Frozen 36/13 pair sets, target-time variants and synthetic shared-bias candidates. See `outputs/mst_review_20261117/reviewer_replay/` and `generated/legacy/`. |

The older 08/09 replay directory records its original diagnostic policy for reproducibility. The current AIRY analyses report continuous diagnostic values and their sensitivity.

Timing residuals, spatial perturbation responses, synthetic absolute errors and injected-increment errors answer different questions. Original video, image files, bag databases, full point clouds and original public HDF recordings are excluded. The field candidate CSV and trajectory CSV contain the timestamps, coordinates, RCS when available and object IDs needed for the numerical analyses. Source and data terms are in [DATA_SOURCES.md](DATA_SOURCES.md).
