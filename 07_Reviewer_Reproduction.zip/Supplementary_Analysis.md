%% Title Supplementary analyses for timing identifiability in opposite-direction LiDAR–radar calibration

# S1. Strict opposite-direction replay

The primary variable-speed AIRY–ARS408 schedule in Figure 10 contains 110 pairs and 220 distinct observations. It was selected by the original planar pairing rule. Two pairs have the same direction sign along the fitted filter axis, with archived member IDs (148, 197) and (1281, 1376). For this sensitivity check, we remove those pairs and keep the rest of the original schedule. The remaining 108 pairs contain 216 distinct observations. The framewise estimator uses the same retained members in receive order. Both schedules use the original fitted axis, reference, prior, and terminal receive epoch. The common prior and terminal receive epochs are 576.926911488 and 804.747943520 s on the archived replay time base.

We compare the archived 110-pair results with a fresh replay on the strict 108-pair subset using all four estimators in Table 13. For each estimator we cross three direction-dependent spatial shifts (−8, 0, and +8 cm) with three timestamp increments (−30, 0, and +30 ms). Both the timing shifts and the direction-dependent position shifts are numerical perturbations of the recorded inputs. The comparison contains 36 configurations per schedule. All 36 strict replay configurations produced an estimate with no failed updates.

For each shift sign, the fitted baseline change is the zero-increment estimate under that spatial shift minus the estimate with zero shift and zero increment. The increment error subtracts the zero-increment estimate at the same spatial shift from the joint-perturbation estimate and then subtracts the imposed timestamp increment. The maximum absolute increment error is computed over the four cases with both a nonzero spatial shift and a nonzero timestamp increment.

Table S1 summarizes the baseline shifts and increment errors on the two schedules.

%% Table Caption **Table S1.** Direction-dependent fitted baseline changes and maximum absolute increment errors before and after removing pairs whose directions along the fitted axis agree. All values are in ms. Each pair of signed baseline changes corresponds to the −8 and +8 cm conditions, in that order.

| Estimator | 110 pairs, baseline changes | 108 pairs, baseline changes | 110 pairs, maximum increment error | 108 pairs, maximum increment error |
| :--- | ---: | ---: | ---: | ---: |
| Original paired EKF | +80.91 / −80.05 | +81.19 / −85.57 | 0.92 | 0.90 |
| Motion-axis paired EKF | +13.14 / −2.53 | +1.97 / −1.34 | 27.90 | 4.26 |
| Robust motion-axis paired EKF | +17.40 / −2.59 | +1.68 / −1.33 | 16.29 | 4.00 |
| Same-model robust framewise EKF | +1.06 / −1.02 | +1.07 / −1.14 | 0.29 | 0.34 |

The original paired EKF's largest absolute increment error on the strict subset occurs at +8 cm and −30 ms. It recovers −30.90365 ms, an increment error of −0.90365 ms. After the same-sign pairs are removed, the fitted baseline still shifts substantially while the increment error remains small. The reductions for the motion-axis paired estimators show that their response magnitudes also depend on pair selection. The offsets and baseline changes remain conditional on the fitted model and replay clock convention. The recordings provide no independent acquisition-time offset against which to assess their absolute error.

# S2. Local scale and absolute error in the existing simulations

We used the continuous-coordinate tracking conditions of Table 11 and the robust motion-axis paired EKF. The two motion conditions and two planted offsets (+70 and +160 ms) give four groups of 30 scheduled runs. For each run, the nominal longitudinal scale is the inverse square root of the projected timing information from the linearized vehicle-X pair contrast after projecting out drift and the direction-centre column. It uses the fixed reference and nominal contrast weights and excludes EKF priors and cross-pair correlations. Terminal absolute error is evaluated against the planted offset.

We computed Spearman's rank correlation between this scale and terminal absolute error within each motion and planted-offset group, assigning average ranks to ties. The pooled correlation is reported for descriptive comparison. One run at +70 ms under variable motion (seed 110) fails a reference update and has no terminal absolute error for the rank calculation. It remains in the scheduled denominator.

%% Table Caption **Table S2.** Spearman rank correlation between the longitudinal local timing scale and terminal absolute error for the robust motion-axis paired EKF in the existing tracking simulations.

| Motion | Planted offset (ms) | Scheduled | Valid | Spearman ρ |
| :--- | ---: | ---: | ---: | ---: |
| Near constant | +70 | 30 | 30 | +0.059 |
| Near constant | +160 | 30 | 30 | +0.251 |
| Variable | +70 | 30 | 29 | −0.174 |
| Variable | +160 | 30 | 30 | +0.188 |
| Pooled | Both | 120 | 119 | +0.332 |

The within-group associations are weak and differ in sign. The pooled coefficient mixes design conditions, and the same seed identifiers are used across conditions. These results support using the local scale to describe sensitivity under the assumed model. A confidence interval, per-run error bound, or acceptance rule would require separate validation.

The accompanying replay script and numerical files contain the signed estimates for all spatial and temporal settings, the per-method summaries, the scheduled simulation runs including the unsupported update, and the grouped rank correlations.

# S3. AIRY board-point timing on the archived pair schedules

Re-extracting the AIRY board observations from 19 November returned 3303 board clusters from 3303 near-constant frames and 3451 clusters from 3456 variable-speed frames. Point counts, frame epochs and board coordinates matched the archived extraction. The board-point time combines the device frame header and the median of the valid within-frame times of the points belonging to that board cluster. Both frame-header and board-point conventions use the original device-to-host translation and original board coordinates. These two conventions assign different observation times to the same spatial measurement. The AIRY device clock remains a relative recording clock, and the ARS408 measurement header uses the host-domain epoch estimated from the start of the reported CAN cycle.

We used the 38 near-constant, 110 primary variable-speed and 49 faster-segment pairs selected by the original planar rule. The corresponding counts of pairs with matching signs on the fitted axis were one, two and zero. The last two faster round trips of the variable-speed recording form the faster segment. The radar coordinates, timestamps, directions, axis, estimator settings and pair identities were shared between both timing conventions. The same-model robust framewise EKF uses each endpoint once in receive order. The 12 frame-header results matched the archive, and all 24 full replays completed without failed reference updates.

For each leave-one replay, we used the original round-trip interval with its 0.65 s clip margin and removed the entire pair if either endpoint fell inside the interval. We kept the prior and terminal receive epochs fixed. If the last retained update preceded the terminal epoch, the estimator propagated its state to that epoch by prediction. Two of seven near-constant omissions removed no pairs. The range and maximum changes in Table S3 use only omissions that removed pairs. There are five such near-constant omissions, eight primary variable-speed omissions and two faster-segment omissions. All 136 omission replays, including the no-change controls, completed without a failed reference update.

%% Table Caption **Table S3.** Terminal offset, range across round-trip omissions and maximum absolute change from the corresponding full-schedule estimate. All values are in ms. Arrows show frame-header timing followed by board-point timing. Framewise rows use both endpoints from the same frozen pairs and are identified by their frame counts.

| Motion | EKF | Support | Terminal offset (ms) | Leave-one range (ms) | Maximum change (ms) |
| :--- | :--- | :--- | ---: | ---: | ---: |
| Near-constant | Original paired | 38 pairs | +26.13 → −47.81 | 89.54 → 55.88 | 64.70 → 27.94 |
| Near-constant | Motion-axis paired | 38 pairs | −107.79 → −166.84 | 65.41 → 228.70 | 54.37 → 210.58 |
| Near-constant | Robust motion-axis paired | 38 pairs | −107.79 → −166.84 | 65.41 → 234.06 | 54.37 → 215.94 |
| Near-constant | Same-model robust framewise | 76 frames | −182.39 → −234.21 | 92.91 → 55.53 | 57.68 → 35.05 |
| Primary variable speed | Original paired | 110 pairs | +28.92 → −55.85 | 51.57 → 46.58 | 29.90 → 25.31 |
| Primary variable speed | Motion-axis paired | 110 pairs | −113.29 → −148.71 | 65.68 → 37.02 | 46.38 → 22.94 |
| Primary variable speed | Robust motion-axis paired | 110 pairs | −112.12 → −149.70 | 63.97 → 37.11 | 44.54 → 23.47 |
| Primary variable speed | Same-model robust framewise | 220 frames | −146.62 → −189.49 | 22.56 → 29.25 | 11.89 → 16.85 |
| Faster segment | Original paired | 49 pairs | +77.08 → −9.20 | 6.36 → 14.79 | 6.90 → 18.14 |
| Faster segment | Motion-axis paired | 49 pairs | +61.25 → +26.52 | 0.15 → 8.80 | 11.56 → 32.39 |
| Faster segment | Robust motion-axis paired | 49 pairs | +61.34 → +27.88 | 0.10 → 9.03 | 11.57 → 31.04 |
| Faster segment | Same-model robust framewise | 98 frames | +107.90 → +93.07 | 50.92 → 26.76 | 35.42 → 36.63 |

We evaluated static losses from −600 to +600 ms at 1 ms increments, with zero drift. At each offset we whitened the residual between the measured and predicted endpoint contrasts using the nominal pair covariance. The motion-axis models fitted a direction-centre contrast along the original axis at each grid point. The two unweighted variants use half the sum of squared whitened residuals. The robust variant uses componentwise Huber loss with a transition at 1.5 standardized residual units. We then divided the loss by the number of pairs. Table S4 gives the grid minima. Figure S1 shows the full curves. Figure S2 shows the terminal EKF results for individual omissions.

Let $U=10^9$ denote nanoseconds per second. For AIRY frame $j$, let $d_j$ and $r_j^{\mathrm L}$ be the device header and recorder receipt in nanoseconds, respectively. The recorder-minus-device differences are $a_j=r_j^{\mathrm L}-d_j$, with $a_0$ denoting the first pooled difference. Let $r_{\min}$ denote the earliest receipt across the two recordings and both sensors. The preparation code rounds the pooled fifth percentile $Q_{0.05}$ relative to $a_0$ to preserve a nanosecond-integer anchor:

$$O_{\mathrm{ns}}=U\left\lfloor\frac{r_{\min}}{U}\right\rfloor,\qquad A_{\mathrm{ns}}=a_0+\operatorname{round}\!\left[Q_{0.05}\bigl(\{a_j-a_0\}_{j}\bigr)\right].$$ {#eq-s3-clock-map}

For valid board points $m\in\mathcal V_j$, let $\tau_{jm}$ be the recorded within-frame time in seconds. The reported ARS408 header $h_i$ and its receipt $r_i^{\mathrm R}$ are in host-domain nanoseconds. The replay epochs are

$$\begin{aligned}t_j^{\mathrm H}&=(d_j+A_{\mathrm{ns}}-O_{\mathrm{ns}})/U,&t_j^{\mathrm B}&=t_j^{\mathrm H}+\delta_j,\\t_i&=(h_i-O_{\mathrm{ns}})/U,&s_i&=(r_i^{\mathrm R}-O_{\mathrm{ns}})/U,\\\delta_j&=\operatorname{median}_{m\in\mathcal V_j}\tau_{jm}.&&\end{aligned}$$ {#eq-s3-board-epochs}

Here $\mathrm H$ and $\mathrm B$ indicate the AIRY frame-header and board-point conventions. Both use the same $A_{\mathrm{ns}}$ and $O_{\mathrm{ns}}$. Neither the pooled anchor nor a board representative time measures the physical intersensor acquisition offset.

In the uniform control, $\Delta$ is the median of the pooled $\delta_j$ from the near-constant and primary variable-speed reference windows. The control translates every reference knot by $\Delta$ and keeps its fitted position and velocity. The translated reference $p_\Delta$ therefore satisfies the following identities on corresponding valid query support, with $C$ standing for any of the static costs defined below:

$$p_\Delta(t)=p(t-\Delta),\qquad p_\Delta\bigl(t_i-(b-\Delta)\bigr)=p(t_i-b),\qquad C_\Delta(b-\Delta)=C(b).$$ {#eq-s3-shift-identity}

Comparing an original grid point with its translated counterpart preserves its loss. Individual board-point corrections can change adjacent spacings, and the board-point reference is refitted.

To compute each static profile, take the archived schedule $\mathcal P$ of $N$ pairs at zero drift. For pair $k$, $e_k$ and $l_k$ as subscripts denote its earlier and later receive indices. Let $p_{xy}$ be the first two components of the reference in the nominal common frame. The per-coordinate measurement noise scales are $\sigma_x,\sigma_y$ and the pair geometry floors are $\sigma_{g,x},\sigma_{g,y}$. The static profiles use the following fixed whitening matrix and covariance:

$$L_{\mathrm{stat}}=\operatorname{diag}\!\left(\sqrt{2\sigma_x^2+\sigma_{g,x}^2},\sqrt{2\sigma_y^2+\sigma_{g,y}^2}\right),\qquad R_{\mathrm{stat}}=L_{\mathrm{stat}}L_{\mathrm{stat}}^\top.$$ {#eq-s3-static-covariance}

This covariance includes the pair geometry floor. It omits the process-noise contribution of the dynamic EKF. Let $q_i$ be the frozen direction labels and $\mathbf a$ the original horizontal motion axis. Write $e_k(b)$ for the whitened contrast residual at $c=0$, $v_k$ for the whitened direction regressor, and $r_k(b,c)$ for the residual with the centre parameter $c$:

$$\begin{aligned}e_k(b)&=L_{\mathrm{stat}}^{-1}\bigl[z_{l_k}-z_{e_k}-p_{xy}(t_{l_k}-b)+p_{xy}(t_{e_k}-b)\bigr],\\v_k&=L_{\mathrm{stat}}^{-1}(q_{l_k}-q_{e_k})\mathbf a,\qquad r_k(b,c)=e_k(b)-v_kc.\end{aligned}$$ {#eq-s3-static-pair-residual}

For the quadratic direction-centre profile, differentiating $\sum_k\|r_k(b,c)\|_2^2$ with respect to $c$ yields the least-squares coefficient

$$\widehat c_{\mathrm{LS}}(b)=\frac{\sum_{k=1}^{N}v_k^\top e_k(b)}{\sum_{k=1}^{N}\|v_k\|_2^2}.$$ {#eq-s3-static-ls-centre}

If the denominator is zero, the least-squares solver selects the minimum-norm coefficient zero. The robust profile instead computes $\widehat c_{\mathrm H}(b)$ by componentwise iteratively reweighted least squares using

$$\rho_\kappa(r)=\frac12\min(|r|,\kappa)^2+\kappa\max(0,|r|-\kappa),\qquad \kappa=1.5.$$ {#eq-s3-static-huber}

The three reported mean losses, with the Huber cost evaluated at the coefficient returned by the solver, are

$$\begin{aligned}C_{\mathrm{diff}}(b)&=\frac{1}{2N}\sum_{k=1}^{N}\|e_k(b)\|_2^2,\\ C_{\mathrm{dir}}(b)&=\frac{1}{2N}\sum_{k=1}^{N}\|r_k(b,\widehat c_{\mathrm{LS}}(b))\|_2^2,\\ C_{\mathrm{rob}}(b)&=\frac{1}{N}\sum_{k=1}^{N}\sum_{\alpha\in\{x,y\}}\rho_\kappa\!\left([r_k(b,\widehat c_{\mathrm H}(b))]_\alpha\right).\end{aligned}$$ {#eq-s3-static-costs}

For each loss we evaluate the same $1201$ values $b_j=-0.600+0.001j$ s for $j=0,\ldots,1200$. A grid point is evaluated only if the reference covers every endpoint. Table S4 reports the first minimum in ascending grid order.

For Table S3, let $I_g$ be the padded receive-time interval for omitted round trip $g$. Its retained set $\mathcal P^{(-g)}$ excludes a pair when either receive epoch is in $I_g$. For each estimator, timing convention and recording, let $\widehat b^{(-g)}$ be the reported offset at the common terminal epoch and $\widehat b^{(\mathrm{full})}$ the corresponding full-schedule offset. The stability summaries use

$$\begin{aligned}\mathcal P^{(-g)}&=\{(e_k,l_k)\in\mathcal P:s_{e_k}\notin I_g,\ s_{l_k}\notin I_g\},\\\mathcal G_+&=\{g:\lvert\mathcal P^{(-g)}\rvert<\lvert\mathcal P\rvert,\ \widehat b^{(-g)}\ \mathrm{available}\}.\end{aligned}$$ {#eq-s3-omission-support}

$$\begin{aligned}R_{\mathrm{omit}}&=\max_{g\in\mathcal G_+}\widehat b^{(-g)}-\min_{g\in\mathcal G_+}\widehat b^{(-g)},\\M_{\mathrm{omit}}&=\max_{g\in\mathcal G_+}|\widehat b^{(-g)}-\widehat b^{(\mathrm{full})}|.\end{aligned}$$ {#eq-s3-omission-metrics}

%% Table Caption **Table S4.** Grid minima and mean losses per pair for the two AIRY timing conventions. Arrows show frame-header timing followed by board-point timing. The asterisk marks a minimum at the edge of the search interval.

| Motion | Static pair model | Minimum (ms) | Mean loss per pair |
| :--- | :--- | ---: | ---: |
| Near-constant | Paired differences | −24 → −98 | 0.5221 → 0.5421 |
| Near-constant | Direction centre | −257 → −331 | 0.4299 → 0.4589 |
| Near-constant | Direction centre + Huber | −255 → −328 | 0.4276 → 0.4563 |
| Primary variable speed | Paired differences | +34 → −56 | 1.0342 → 1.0180 |
| Primary variable speed | Direction centre | −73 → −600* | 0.8884 → 0.8684 |
| Primary variable speed | Direction centre + Huber | −79 → −149 | 0.7890 → 0.7727 |
| Faster segment | Paired differences | +78 → −7 | 0.6718 → 0.7059 |
| Faster segment | Direction centre | +77 → +17 | 0.6718 → 0.7022 |
| Faster segment | Direction centre + Huber | +81 → +40 | 0.6452 → 0.6653 |

In the uniform-shift control, adding the pooled main-window median of +95.884 ms to every old LiDAR epoch translates the static profile by −95.884 ms over the common support. The measured point-time corrections vary by cluster. With board-point timing, the near-constant, primary variable-speed and faster references had 77, 58 and 11 adjacent knots less than 20 ms apart. The shortest gap was about 2 ms and the longest about 198 ms, within the original 350 ms maximum gap for interpolation. The original coordinates represent spatial measurements across a scan. Assigning a median time to the cluster therefore changes the interpolated reference and can change the timing fit beyond the shift in origin.

The primary variable-speed run yielded a smaller leave-one range in both motion-axis paired filters and a larger range in the same-model framewise filter. The near-constant run yielded substantially larger ranges in both paired filters with a direction-centre state. These comparisons describe how the estimates vary when individual trips are omitted from the two recordings while the trajectory reference is kept fixed. The near tie between −147 and −600 ms makes the unweighted direction-centre result sensitive to the loss and the search domain. Absolute acquisition-time accuracy requires a separately timed physical reference.

![Static offset cost over the search grid on all three fixed pair schedules](figures/point_timing_cost_en.png){width=16.7cm}

%% Image Caption **Figure S1.** Mean static loss per pair with AIRY frame-header and board-point timing. Each marker denotes the grid minimum in that curve. The unweighted direction-centre panel for the primary variable-speed schedule has nearly equal board-point costs at −147 and −600 ms. The Huber model places the grid minimum at −149 ms.

![Terminal offset for each omitted recorded round trip](figures/point_timing_stability_en.png){width=16.7cm}

%% Image Caption **Figure S2.** Terminal EKF offsets by omitted round trip with fixed origin mapping, initial epoch and evaluation epoch. Each paired estimator uses the same eligible pairs for both timing conventions. The framewise estimator uses their distinct endpoints. The hollow markers identify omissions that removed no pairs. Compare the change between timing conventions within each panel. The final column uses only two faster round trips.

# S4. Radar Ghost sampling coverage and fixed-pair replay

The retrospective public-data screen compared the original 0.13 s minimum interval, a strict 0.10 s minimum and native-frame selection. Table S5 combines the four streams with at most one nonreused pair. A single pair contains two distinct observations. These streams were not used for profile fits or fixed-pair comparisons. The sequence identifiers and common pairing criteria are given in Sections 3.2 and 3.3 of the manuscript.

%% Table Caption **Table S5.** Nonreused pair counts for the four Radar Ghost streams that yielded at most one pair. A count of 0 denotes a screened stream with no eligible pairs.

| Sequence / radar | 0.13 s | Strict 0.10 s | Native frames |
|:---|---:|---:|---:|
| G01-C / right | 0 | 1 | 1 |
| G01-P / left | 0 | 0 | 0 |
| G01-P / right | 0 | 0 | 0 |
| G18-C / left | 0 | 1 | 1 |

G01-C/left yielded 3, 7 and 14 pairs, respectively. The 14 native-frame pairs supplied 28 distinct observations for the EKF comparison in Table 8 of the manuscript, below the 30-observation minimum for offline profiles. The common prior was at 3.198497 s. The fixed pair-completion epochs spanned 17.768637–19.198346 s. All endpoints supported an update in each condition of the five-by-three perturbation matrix. The implementation log records 3,990 supported reference queries, including repeated completed-prefix replays.

The difference EKF cancelled the common displacement to numerical precision. For the two direction-changing polarities, the terminal offset changes were −18.017/+18.207 ms and the median single-pair equivalent change from the two speed magnitudes was 18.09 ms. For the positive and negative direction shifts in that order, the spatial-response RMS values were 17.566 and 17.733 ms. Under those same shifts, the ±30 ms recovery RMSEs were 0.187 and 0.168 ms when measured relative to the corresponding displaced zero-injection baselines. Subtracting that baseline can cancel a bias shared by both estimates.

Figure S3 shows the displacement responses at the fixed endpoints.

![Second public recording offset responses](figures/figure_4_ghost01_response.png){width=13.6cm}

%% Image Caption **Figure S3.** G01-C/left fixed 14-pair replication. Common displacement cancels in the difference estimator, whereas direction displacement changes its offset trajectory. The nominal offsets are conditional estimates, not errors against a hardware reference.

Figure S4 displays nominal-coordinate timestamp-increment recovery.

![G01-C time increment recovery](figures/figure_5_injection_response.png){width=13.6cm}

%% Image Caption **Figure S4.** G01-C/left nominal-coordinate ±30 ms increment recovery at the same 14 completed-pair endpoints. The vertical axis is recovered increment minus the imposed increment. These curves measure local timestamp response and do not establish absolute clock accuracy.

# S5. Association and timing-scale diagnostics

Figure S5 shows the sensitivity checks from Section 4.12.2 and Table 14 of the manuscript. The association check changes the radar selection rule on the same matched frames. The traversal check omits one round trip and matches the two arms again.

![Conditional offset candidates under alternative association and traversal omission](figures/association_sensitivity_en.png){width=16.4cm}

%% Image Caption **Figure S5.** Association and traversal sensitivity of field timing candidates. In (a), each segment connects LiDAR-gated and radar-only association on the same 409 direction- and range-matched frames per arm for the indicated model. In (b), direction-centre candidates are refitted after omitting one round trip, including its 0.65 s margins, and rematching both arms. Each scenario retains 350–394 observations per arm. Dashed lines show the corresponding full-schedule candidates. All offsets are fitted on the replay time base.

Figure S6 displays the trial-level data behind Table S2. The within-condition rank associations vary in sign and size. The pooled association is descriptive and combines conditions with different scale distributions.

![Local timing scale and absolute terminal timing error across simulation trials](figures/simulation_scale_en.png){width=15.2cm}

%% Image Caption **Figure S6.** Longitudinal local timing scale and terminal absolute time-offset error for the robust motion-axis paired EKF using tracked, continuous-coordinate observations in the 3–6 m simulation. Each point represents an evaluable trial. Panels share the linear scale axis and the logarithmic error axis. In the variable-speed condition at +70 ms, a failed reference update leaves 29 of 30 trials with terminal errors. The plotted 119 trials give a pooled Spearman coefficient of +0.332. The local scale uses nominal weights after projecting out drift and the direction-centre term.

# S6. Complete estimator derivations and implementation equations

## S6.1. LiDAR reference support and interpolation

For the LiDAR target coordinates $x_j^{\mathrm L}$, let $\ell_j$ denote their strictly increasing epochs. A gap above $g=0.35$ s starts a new segment. For the segment $\mathcal R_j$ containing sample $j$, the nominal half-window $H=0.45$ s defines the local support, polynomial degree and Gaussian row factor.

$$\begin{aligned}\mathcal N_j&=\{k\in\mathcal R_j:|\ell_k-\ell_j|\le H\},\qquad m_j=\min(2,|\mathcal N_j|-1),\\w_{jk}&=\exp\left[-\frac12\left(\frac{\ell_k-\ell_j}{H/2}\right)^2\right].\end{aligned}$$ {#eq-lidar-local-support}

Writing $\boldsymbol\beta_j=(\beta_{j0},\ldots,\beta_{jm_j})$ for the vector-valued coefficients, the row factor multiplies both the design row and the measured position in the least-squares system.

$$\widehat{\boldsymbol\beta}_j\in\operatorname{argmin}_{\boldsymbol\beta_j}\sum_{k\in\mathcal N_j}w_{jk}^2\left\|x_k^{\mathrm L}-\sum_{r=0}^{m_j}\beta_{jr}(\ell_k-\ell_j)^r\right\|_2^2.$$ {#eq-lidar-local-fit}

The fitted knot position is $P_j=\widehat\beta_{j0}$. The fitted velocity is $V_j=\widehat\beta_{j1}$ if $m_j\ge1$ and zero if $m_j=0$. The query at $t$ requires the following bracket.

$$\ell_j\le t<\ell_{j+1},\qquad h_j=\ell_{j+1}-\ell_j\le g,\qquad u=\frac{t-\ell_j}{h_j}.$$ {#eq-lidar-query-bracket}

A query without such a bracket is unsupported. Within the bracket, cubic Hermite interpolation gives the position.

$$\begin{aligned}p(t)={}&(2u^3-3u^2+1)P_j+(u^3-2u^2+u)h_jV_j\\&+(-2u^3+3u^2)P_{j+1}+(u^3-u^2)h_jV_{j+1}.\end{aligned}$$ {#eq-lidar-hermite-position}

Differentiation gives the reference velocity used in the measurement model.

$$\dot p(t)=\frac{6u^2-6u}{h_j}(P_j-P_{j+1})+(3u^2-4u+1)V_j+(3u^2-2u)V_{j+1}.$$ {#eq-lidar-hermite-velocity}

Both positions and velocities are held fixed in the clock estimation. The state covariance excludes shared LiDAR reference uncertainty. Radar observations are planar target coordinates in the nominal common frame. The offline diagnostic fixes drift to zero. The sequential controls estimate drift and offset in receive time. Their uncertainty outputs refer to those distinct models.

## S6.2. Scalar contrast, gain and information derivations

For a local residual $r_i=G_i\eta+h_i b+\epsilon_i$, $\eta$ collects shared geometric parameters, $h_i$ is the coefficient of the offset and $\epsilon_i$ is the noise. For a late and an early observation, subtract in the same order in the model and the data.

$$\begin{aligned}r_l-r_e&=(G_l-G_e)\eta+(h_l-h_e)b+(\epsilon_l-\epsilon_e),\\\|(G_l-G_e)\eta\|&\le L\|p_l-p_e\|\|\eta\|.\end{aligned}$$ {#eq-local-contrast}

The bound assumes $G$ is locally Lipschitz in physical position with constant $L$. A common additive displacement cancels exactly. Proximity judged at uncorrected reported times approximates proximity of $p_l,p_e$. In the directional scalar model of Section 2.2, write $\Delta\epsilon_k=\epsilon_{k+}-\epsilon_{k-}$ and $\bar\epsilon_k=(\epsilon_{k+}+\epsilon_{k-})/2$. Independent equal-variance endpoint noise gives

$$\begin{aligned}\operatorname{Var}(\Delta\epsilon_k)&=2\sigma^2,\qquad \operatorname{Var}(\bar\epsilon_k)=\frac{\sigma^2}{2},\\ \operatorname{Cov}(\Delta\epsilon_k,\bar\epsilon_k)&=\frac{\operatorname{Var}(\epsilon_{k+})-\operatorname{Var}(\epsilon_{k-})}{2}=0.\end{aligned}$$ {#eq-contrast-noise}

The scalar comparison orders observations by motion direction. The sequential filter in Section 2.3 uses receive-time order. Reversing both the predicted and measured differences reverses the sign of the contrast.

For the gain calculation fix $b$ across observations, take $u_k=u$, $w_k=w$ and form pairs at the same underlying positions. Set $A=u^2+w^2$, $S=u+w$ and $D=u-w$. A framewise timing-only fit that omits both spatial terms minimises the sum of $(r_{k+}+u\beta)^2+(r_{k-}-w\beta)^2$ over trial offsets $\beta$. The paired timing-only fit minimises the sum of $(\Delta r_k+S\beta)^2$. The normal equations yield

$$\begin{aligned}\hat b_f&=-\frac{\sum_k(u r_{k+}-w r_{k-})}{nA}\\&=b-\frac{aD+cS}{A}-\frac{\sum_k(u\epsilon_{k+}-w\epsilon_{k-})}{nA},\\\hat b_p&=-\frac{\sum_k\Delta r_k}{nS}=b-\frac{2c}{S}-\frac{\sum_k\Delta\epsilon_k}{nS}.\end{aligned}$$ {#eq-timing-only-estimators}

Taking means and variances gives Equation (4) of the main text. The mean-square error is squared bias plus variance. The identity $2A-S^2=D^2$ gives

$$\begin{aligned}\operatorname{Var}(\hat b_p)-\operatorname{Var}(\hat b_f)&=\frac{\sigma^2D^2}{nAS^2},\\\operatorname{MSE}(\hat b_p)-\operatorname{MSE}(\hat b_f)&=\frac{4c^2}{S^2}-\frac{(aD+cS)^2}{A^2}+\frac{\sigma^2D^2}{nAS^2}.\end{aligned}$$ {#eq-pair-mse-gap}

At $c=0$ this factors as Equation (5) of the main text. For $D\ne0$, pairing reduces RMSE precisely when $|a|>\sigma\sqrt{A}/(\sqrt n S)$, with equal RMSE at equality. For $D=0$, the timing-only estimators coincide. In a framewise fit with free $a$ and $c=0$, eliminating $a$ centres the signed velocities to $S/2$ and $-S/2$. The normal equation then reduces to the paired expression in @eq-timing-only-estimators. This augmented fit represents the common-displacement model. The calculated pairing gain is relative to the timing-only framewise baseline and serves as a fixed-offset reference for the dynamic EKF simulations.

With variable motion and free $a,c$, centring the pair differences and means eliminates the two intercepts. Bars denote averages across pairs.

$$\begin{aligned}\Delta r_k-\overline{\Delta r}&=-(S_k-\bar S)b+\Delta\epsilon_k-\overline{\Delta\epsilon},\\m_k-\bar m&=-\frac{D_k-\bar D}{2}b+\bar\epsilon_k-\frac{1}{n}\sum_j\bar\epsilon_j.\end{aligned}$$ {#eq-centred-pair-regression}

For the original framewise observations, let $B=[\mathbf 1,q]$ and let $P_B$ be orthogonal projection onto its span. Projecting out both spatial terms is equivalent to centring $v_i$ around the mean signed velocity $\bar v_q$ in each direction.

$$I_b=\sigma^{-2}v^\text{T}(I-P_B)v=\sigma^{-2}\sum_{q\in\lbrace-1,+1\rbrace}\sum_{i:q_i=q}(v_i-\bar v_q)^2.$$ {#eq-e3}

The uncentred difference and mean errors have variances $2\sigma^2$ and $\sigma^2/2$ and zero covariance. Weighting the two centred derivatives by their corresponding inverse variances gives Equation (6) of the main text. The difference-and-mean transformation is invertible with both components present, preserving framewise information. If both legs are individually constant, the framewise design also loses rank because $v_i=(D+Sq_i)/2$, including when $u\ne w$. Speeds $(u_k,w_k)=(1,2)$ and $(2,1)$ m/s give zero paired information and positive framewise information despite within-leg speed variation. This scalar result assumes a fixed offset and independent equal-variance observations. With a single direction, the two spatial terms reduce to one intercept. Nonconstant signed velocity can still identify $b$.

For a scalar pair with the fitted model setting $c=0$, equate $2c-S_k b$ to $-S_k b_{\mathrm{app}}$ to obtain Equation (7) of the main text. At equal speed magnitude $s$, $b_{\mathrm{app}}=b-c/s$. A direction-dependent shift of amplitude 0.08 m produces a contrast of magnitude 0.16 m, corresponding locally to $0.16/(u_k+w_k)$ s.

## S6.3. Clock process, observation slopes and EKF updates

The active state is $x=[b,d]^\text{T}$ with deterministic drift $d=\mathrm db/\mathrm ds$. These states form the radar block of the original four-state radar/camera implementation. The fixed-pair comparisons assimilate radar observations using the fixed LiDAR reference. Independent Wiener increments $W_b,W_d$ with process-noise densities $q_b,q_d$ act on the receive clock $s$.

$$\begin{aligned}\mathrm db&=d\,\mathrm ds+\sqrt{q_b}\,\mathrm dW_b,\\\mathrm dd&=\sqrt{q_d}\,\mathrm dW_d.\end{aligned}$$ {#eq-clock-continuous}

Integrating over a receive-time step $\Delta s$ gives the transition $F$ and covariance $Q$.

$$\begin{aligned}F(\Delta s)&=\begin{bmatrix}1&\Delta s\\0&1\end{bmatrix},\\Q(\Delta s)&=q_d\begin{bmatrix}\Delta s^3/3&\Delta s^2/2\\\Delta s^2/2&\Delta s\end{bmatrix}+q_b\begin{bmatrix}\Delta s&0\\0&0\end{bmatrix}.\end{aligned}$$ {#eq-e4}

For posterior state $x^+$ and covariance $P^+$ from the previous update, predict

$$x^-=F(\Delta s)x^+,\qquad P^-=F(\Delta s)P^+F(\Delta s)^\text{T}+Q(\Delta s).$$ {#eq-clock-prediction}

The baseline uses $q_d=2\times10^{-9}$ and $q_b=2\times10^{-7}$, a zero initial state and independent initial standard deviations of 0.12 s in offset and 0.001 s/s in drift. Single-observation noise is $\Sigma_r=\operatorname{diag}(\sigma_x^2,\sigma_y^2)$ with $(\sigma_x,\sigma_y)=(0.15,0.10)$ m.

For observation $i$ set $b_i=b(s_i)$, $p_i=p(t_i-b_i)$ and $v_i=\dot p(t_i-b_i)$. The positive offset queries an earlier reference epoch. The vehicle implementation uses a centred difference of projected positions with $\varepsilon=10^{-4}$ s. For the affine radar position projection the difference equals the chain-rule slope.

$$\begin{aligned}f_i(b_i)&=\pi[p(t_i-b_i)],\\h_i&=\frac{\partial f_i}{\partial b_i}=-J_\pi(p_i)v_i,\\h_i&\simeq\frac{\pi(p_i-\varepsilon v_i)-\pi(p_i+\varepsilon v_i)}{2\varepsilon}.\end{aligned}$$ {#eq-clock-measurement-slope}

After prediction to $s_i$, the framewise innovation, Jacobian and measurement covariance are

$$\nu_i=z_i-f_i(b_i),\qquad H_i=[h_i,\ 0],\qquad R_i=\Sigma_r.$$ {#eq-clock-framewise}

The drift column is zero at the measurement's receive epoch. Drift enters the offset through @eq-e4. For a pair evaluated at its late member, the earlier deterministic offset is $b_e=b-\Delta d$. Its drift derivative $-\Delta$ gives the positive coefficient of $\Delta h_e$ in the contrast Jacobian in Equation (8) of the main text.

Let $[w_b,w_d]^\text{T}$ denote the process increment from $s_e$ to $s_l$ with covariance $Q(\Delta)$. From $d_l=d_e+w_d$ and $b_l=b_e+\Delta d_e+w_b$, eliminate $d_e$.

$$\begin{aligned}b_e^{\mathrm{stoch}}&=b-\Delta d-(w_b-\Delta w_d),\\\operatorname{Var}(w_b-\Delta w_d)&=[1,\ -\Delta]Q(\Delta)[1,\ -\Delta]^\text{T}\\&=q_b\Delta+q_d\Delta^3/3=Q_{00}(\Delta).\end{aligned}$$ {#eq-pair-clock-variance}

The implementation approximates extra contrast noise by this marginal variance. Its paired covariance in Equation (9) of the main text combines two independent nominal observation terms, geometry allowance $(\sigma_{g,x},\sigma_{g,y})=(0.04,0.04)$ m and the linearized contribution from the earlier query. This approximation omits the clock-noise correlation with the state, correlations between pair updates with overlapping time intervals and shared LiDAR reference errors.

Let $\nu,H$ denote the observation or contrast innovation and Jacobian. The effective covariance $R_{\mathrm{eff}}$ is nominal in the unweighted branch and is given by the Huber rule of S6.5 in the robust branch. The update uses the innovation covariance, gain and Joseph form.

$$\begin{aligned}S_{\mathrm{eff}}&=HP^-H^\text{T}+R_{\mathrm{eff}},\\K&=P^-H^\text{T}S_{\mathrm{eff}}^{-1},\qquad x^+=x^-+K\nu,\\P^+&=(I-KH)P^-(I-KH)^\text{T}+KR_{\mathrm{eff}}K^\text{T}.\end{aligned}$$ {#eq-clock-joseph}

The code obtains $K$ by a linear solve and symmetrizes the posterior covariance. For the completed-prefix baseline, number pairs in completion order. The observation indices of the first $k$ completed pairs form

$$\mathcal O_k=\bigcup_{j=1}^k\{e_j,l_j\},\qquad|\mathcal O_k|=2k.$$ {#eq-clock-completed-support}

The framewise EKF restarts from the common prior for each comparison, sorts $\mathcal O_k$ by receive time and evaluates at $s_{l_k}$. An auxiliary raw stream may include early members of pairs still open at an intermediate epoch. At the final endpoint it has consumed the same members as the completed-prefix replay and gives the same estimate. For terminal-only comparisons, the framewise filter processes all frozen members chronologically from the common prior. If the last retained update precedes the fixed epoch in an omission check, the filter predicts forward to that epoch. Pairing still uses contrasts and their covariance, so matching observation members and epochs preserves the input set without making the filters equivalent. The mean-and-contrast transformation is invertible if both components and their joint covariance are retained.

The known-clock synthetic control uses an augmented framewise EKF with constant planar displacement $\boldsymbol{\ell}$.

$$\begin{aligned}x_{\ell}&=[b,d,\ell_x,\ell_y]^\text{T},\qquad \boldsymbol{\ell}=[\ell_x,\ell_y]^\text{T},\\\hat z_i&=f_i(b_i)+\boldsymbol{\ell},\qquad H_i=[h_i,\ 0,\ I_2].\end{aligned}$$ {#eq-clock-translation-control}

The displacement propagates by $I_2$ with zero process noise and an independent zero-mean prior of standard deviation 0.30 m per axis. Two alternatives use 0.15 and 0.60 m. All three filters use the same 32 chronological observation identities, clock prior epoch and final receive epoch in each trial. The augmented framewise filter uses @eq-e4 and single-observation noise $\Sigma_r$. The paired filter uses Equation (9) of the main text.

## S6.4. Offline profiles and local scale constructions

For constant offset $b$, define $p_i=p(t_i-b)$, $y_i(b)=\pi(p_i)$, spatial Jacobian $J_i$, nominal sensor centre $o$, frozen dominant motion axis $u$, frozen direction $q_i$ and Cartesian unit vectors $e_x,e_y,e_z$. The direction model has design

$$G_i(b)=\left[J_i e_x,\;J_i e_y,\;J_i\{e_z\times(p_i-o)\},\;J_i u q_i\right].$$ {#eq-e7}

The geometry design keeps the first three columns for two shared translations and yaw. The direction-centre column adds coefficient $c$. The fitted coefficients can absorb geometric and feature-centre discrepancies jointly. Interpreting them as mounting parameters requires independent verification. The spatial Jacobian uses central differences.

$$J_i e_j\approx\frac{\pi(p_i+\varepsilon_p e_j)-\pi(p_i-\varepsilon_p e_j)}{2\varepsilon_p},\qquad j\in\{x,y,z\},\quad\varepsilon_p=10^{-4}\ \mathrm{m}.$$ {#eq-profile-spatial-difference}

Stack measurements, predictions and design by observation and coordinate as $z,y,G$. Coordinate $j$ has nominal noise standard deviation $\sigma_j$. Standardisation gives

$$\begin{aligned}D_\sigma&=\operatorname{diag}(\sigma_j),\qquad r_0(b)=D_\sigma^{-1}[z-y(b)],\\G_w(b)&=D_\sigma^{-1}G(b),\qquad r_w(b,\eta)=r_0(b)-G_w(b)\eta.\end{aligned}$$ {#eq-profile-whitening}

The componentwise Huber loss for the offline profile is

$$\rho_\kappa(r)=\begin{cases}r^2/2,& |r|\le\kappa,\\\kappa(|r|-\kappa/2),& |r|>\kappa,\end{cases}\qquad\kappa=1.5.$$ {#eq-profile-huber-loss}

The objective in Equation (10) of the main text is minimised approximately by iteratively reweighted least squares. At iteration $m$,

$$\begin{aligned}w_j^{(0)}&=1,\qquad W^{(m)}=\operatorname{diag}(w_j^{(m)}),\\\eta^{(m+1)}&=\operatorname{argmin}_\eta\|(W^{(m)})^{1/2}[r_0(b)-G_w(b)\eta]\|_2^2,\\r^{(m+1)}&=r_w(b,\eta^{(m+1)}),\qquad w_j^{(m+1)}=\min\!\left(1,\frac{1.5}{\max(|r_j^{(m+1)}|,10^{-12})}\right).\end{aligned}$$ {#eq-profile-irls}

The relative singular-value cutoff is $10^{-8}$. Iteration stops when $\max_j|w_j^{(m+1)}-w_j^{(m)}|<10^{-6}$ or when 50 iterations are reached. The returned cost is the sum of Huber losses evaluated at the returned residual. After a 10 ms grid search on $[-0.6,0.6]$ s, 26 golden-section iterations refine the best sampled point between adjacent grid points within the search bounds. This refines the selected local interval in a multimodal profile. Nuisance bounds are checked after unconstrained fitting. Candidates outside the declared domain are retained for audit with corresponding fit flags.

At $(\hat b,\hat\eta)$ hold the fitted nuisance coefficients and final weight matrix $W$ fixed. Differentiate the complete whitened prediction.

$$\begin{aligned}\phi(b;\hat\eta)&=D_\sigma^{-1}[y(b)+G(b)\hat\eta],\\h&\approx\frac{\phi(\hat b+\varepsilon_b;\hat\eta)-\phi(\hat b-\varepsilon_b;\hat\eta)}{2\varepsilon_b},\qquad\varepsilon_b=10^{-4}\ \mathrm{s}.\end{aligned}$$ {#eq-profile-clock-difference}

The derivative thus includes the offset dependence of $G$. In Equation (11) of the main text, $\sigma_j(A)$ are singular values in descending order and $U_r$ contains the first $r$ left singular vectors. The projection onto an empty design span is zero. The ratio $f_{\mathrm{ret}}$ is relative to the unprojected weighted offset derivative. For a common point with geometry basis $Q_G$, let $a_c$ be the weighted direction column. If the direction span equals the span of $(Q_G,a_c)$,

$$\begin{aligned}P_G&=Q_GQ_G^\text{T},\qquad a_\perp=(I-P_G)a_c,\qquad h_\perp=(I-P_G)h_w,\\I_D&=I_G-\frac{(a_\perp^\text{T}h_\perp)^2}{\|a_\perp\|_2^2},\qquad a_\perp\ne0.\end{aligned}$$ {#eq-profile-direction-projection}

The identity projects the geometry residual onto the additional unit direction $a_\perp/\|a_\perp\|_2$. When $a_\perp=0$, no direction is added and $I_D=I_G$. At the same derivative, support and weights with nested spans, $I_D\le I_G$. Separate fits can change these inputs. The ratio $I_D/I_G$ for $I_G>0$ compares two nuisance models and has a different denominator from $f_{\mathrm{ret}}$. Frozen-weight information quantifies conditional local sensitivity. Exact Fisher information under a robust likelihood would require the full likelihood.

In the fitted-point scale of Equation (12) of the main text, count occupied one-second bins of receive time $s_i$ over $n$ retained observations.

$$B_{\mathrm{occ}}=\left|\left\{\left\lfloor\frac{s_i-\min_j s_j}{1\ \mathrm{s}}\right\rfloor:\ i\ \text{retained}\right\}\right|.$$ {#eq-profile-occupied-bins}

The archived implementation reports a numerical scale for $I_{\mathrm{prof}}>10^{-16}\ \mathrm{s}^{-2}$. Bin inflation is heuristic. Dependence between bins and shared LiDAR reference errors can remain. For Table 6 the scale is reported continuously alongside the selected fit flags of Section 3.4.

Table 12 uses a framewise operating point at $b=0$ and $\eta=0$ with nominal independent weights.

$$h_0\approx D_\sigma^{-1}\frac{y(\varepsilon_b)-y(-\varepsilon_b)}{2\varepsilon_b},\qquad A_0=D_\sigma^{-1}G(0),\qquad s_{D,0}=\frac{1000}{\sqrt{I_{D,0}}}\ \mathrm{ms}.$$ {#eq-framewise-nominal-scale}

Here $I_{D,0}$ is the squared norm of the derivative after projection onto the orthogonal complement of the direction nuisance span using $A_0$. Table 12 also compares the geometry-only projection at the same point. The calculation excludes Huber reweighting and block inflation.

The paired longitudinal scale in Sections 4.11 and 4.12.1 uses vehicle-X contrasts at nominal zero offset and drift with no prior information. For pair $k$ let $s_{e_k},s_{l_k}$ be its receive epochs. Use $b_T$ at the final pair-completion epoch $s_T$ and affine drift $d$. The nominal offset slope in vehicle X is $h_{i,x}$, and the direction labels are $-\operatorname{sign}(h_{i,x})$. The contrast derivatives with respect to final offset, drift and the X-axis centre term are

$$\begin{aligned}s_T&=\max_k s_{l_k},\qquad b(s_i)=b_T+(s_i-s_T)d,\qquad \Delta_k=s_{l_k}-s_{e_k},\\g_{b,k}&=h_{l_k,x}-h_{e_k,x},\\g_{d,k}&=(s_{l_k}-s_T)h_{l_k,x}-(s_{e_k}-s_T)h_{e_k,x}=(s_{l_k}-s_T)g_{b,k}+\Delta_k h_{e_k,x},\\g_{c,k}&=\operatorname{sign}(h_{e_k,x})-\operatorname{sign}(h_{l_k,x}).\end{aligned}$$ {#eq-paired-scale-jacobians}

Whiten each pair using the X marginal of Equation (9) of the main text.

$$\begin{aligned}\left[\gamma_b,\gamma_d,\gamma_c\right]_{k,:}&=\frac{[g_{b,k},g_{d,k},g_{c,k}]}{\sqrt{[R_{\mathrm{pair},k}]_{xx}}},\\I_{x,0}&=\|(I-P_{\gamma_d})\gamma_b\|_2^2,\qquad I_{x,c}=\|(I-P_{[\gamma_d,\gamma_c]})\gamma_b\|_2^2,\\s_x&=\frac{1000}{\sqrt{I_{x,c}}}\ \mathrm{ms}.\end{aligned}$$ {#eq-paired-longitudinal-scale}

For indicated columns $B$, $P_B$ projects onto their supported span. The code discards zero nuisance columns, normalises the nonzero columns before projection and uses relative singular-value cutoff $10^{-10}$. Projected information no greater than $10^{-22}\|\gamma_b\|_2^2$ is treated as numerical zero. The scale is reported when $I_{x,c}>0$. This conditions on the LiDAR reference and assumes independent pair errors, with no prior or Huber weights. A smaller scale means stronger local constraint under the specified model and support.

## S6.5. Motion-axis centre state and robust measurement update

The horizontal unit axis $\mathbf a$ for the constant centre displacement $c$ is either vehicle X or a dominant axis from the LiDAR reference. For the LiDAR variant, let $v_{j,\mathrm{xy}}$ be the horizontal reference velocity at knot $j$. Use finite velocities at or above 0.10 m/s, form the uncentred second moment and take its leading unit eigenvector $\tilde{\mathbf a}$.

$$\begin{aligned}\mathcal M&=\{j:\ v_{j,\mathrm{xy}}\ \text{finite},\ \|v_{j,\mathrm{xy}}\|\ge 0.10\ \mathrm{m/s}\},\\M&=\sum_{j\in\mathcal M}v_{j,\mathrm{xy}}v_{j,\mathrm{xy}}^\text{T},\\M\tilde{\mathbf a}&=\lambda_{\max}(M)\tilde{\mathbf a},\qquad \|\tilde{\mathbf a}\|=1.\end{aligned}$$ {#eq-centre-motion-axis}

At least two moving knots are required. The implementation rejects an eigengap no greater than $10^{-8}\lambda_{\max}(M)$. Fix the sign by making the largest-magnitude axis component positive. At the nominal selection epoch $t_i^{\mathrm{sel}}$, define the direction label.

$$j_\star=\operatorname{argmax}_j|\tilde a_j|,\qquad \mathbf a=\operatorname{sgn}(\tilde a_{j_\star})\tilde{\mathbf a},\qquad q_i=\operatorname{sgn}(\mathbf a^\text{T}v_{\mathrm{xy}}(t_i^{\mathrm{sel}})).$$ {#eq-centre-axis-sign}

A supported centre update requires $q_i\in\lbrace-1,+1\rbrace$. Perturbation replays keep labels and the axis fixed. The augmented clock state and propagation are

$$x_c=[b,d,c]^\text{T},\qquad F_c=\operatorname{diag}(F,1),\qquad Q_c=\operatorname{diag}(Q,0).$$ {#eq-centre-clock-transition}

The displacement has independent zero-mean prior with standard deviation 0.15 m and zero process noise. The framewise model gives

$$\hat z_{i,c}=f_i(b_i)+q_i c\mathbf a,\qquad H_{i,c}=[h_i,\ 0,\ q_i\mathbf a],\qquad \nu_i=z_i-\hat z_{i,c}.$$ {#eq-centre-framewise}

For a pair evaluated at $s_l$, use the earlier offset and slopes of Equation (8) of the main text.

$$\begin{aligned}\Delta\hat z_c&=f_l(b)-f_e(b_e)+(q_l-q_e)c\mathbf a,\\H_{\mathrm{pair},c}&=[h_l-h_e,\ \Delta h_e,\ (q_l-q_e)\mathbf a],\\\nu_{\mathrm{pair}}&=z_l-z_e-\Delta\hat z_c.\end{aligned}$$ {#eq-centre-paired}

Opposite signs give $q_l-q_e=\pm2$. Sign agreement cancels the added displacement. The nominal covariances remain $\Sigma_r$ and the pair covariance of Equation (9) of the main text.

The robust branch starts with nominal covariance $R$, innovation $\nu$ and prior covariance $P^-$. It uses the lower Cholesky factor $L$ of the nominal predictive covariance to compute the standardized radius and the effective measurement covariance.

$$\begin{aligned} S_{\mathrm{nom}}&=HP^-H^\text{T}+R,\qquad S_{\mathrm{nom}}=LL^\text{T},\\D&=\|L^{-1}\nu\|,\qquad \kappa=\sqrt{5.991},\\w&=\begin{cases}1,&D\le\kappa,\\\kappa/D,&D>\kappa,\end{cases}\qquad R_{\mathrm{eff}}=R/w.\end{aligned}$$ {#eq-centre-huber-update}

The unweighted branch has $w=1$. The framewise variant evaluates the radius for each position and the paired variant evaluates it for each contrast. Both compute the radius before changing $R$ and recompute $S_{\mathrm{eff}}$ once in @eq-clock-joseph using $R_{\mathrm{eff}}$. The offline profile instead uses the componentwise loss of @eq-profile-huber-loss.

# S7. Reference-window and clock-model sensitivity

Table S6 includes all reference-window branches, including non-evaluable fixed supports.

%% Table Caption **Table S6.** Fixed-support reference half-window ablation. Each cell gives $s_b$ in ms for the geometry and direction models, in that order. A reference half-window of 0.45 s is the primary setting.

| Fixed support | 0.30 s | 0.45 s | 0.60 s |
|:----|:-----|:-----|:-----|
| 08 near-constant, 64 observations | One point outside direction and speed screen | 27.631 / 171.142 | 27.522 / 172.072 |
| 08 variable, 64 observations | One point outside direction and speed screen | 25.799 / 101.971 | 25.892 / 107.820 |
| 09 full support, 79 observations | Two points outside direction and speed screen | 27.227 / 100.731 | 27.294 / 104.876 |
| G18-C / right, 32 observations | 13.667 / 90.981† | 13.642 / 115.508† | 13.652 / 146.979† |

%% Table Note †Public direction entries are scales evaluated at out-of-domain centre candidates. The supplementary numerical files record the fit checks and nuisance coefficients.

The shorter window retains the observations in the experiment manifest. The three in-house profiles are unevaluable on those fixed supports because the observations listed in Table S6 fall outside the direction and speed screen. At 0.60 s, the two 08 direction fits still exhibit split instability. The nominal variable/near-constant direction-information ratio changes from 2.928 at 0.45 s to 2.505 at 0.60 s. Variable speed yields more direction-model information under both references, with the magnitude of that advantage depending on the window.

For G18-C/right, fixed-zero-point direction information is 265.204, 127.733 and 81.407 s$^{-2}$ at half-windows 0.30, 0.45 and 0.60 s. The geometry information remains approximately 47,435–47,854 s$^{-2}$. Thus smoothing has a substantial effect on the small information component that remains after direction projection. All three original-style direction candidates are rejected, with their centre coefficients near −2.16 m. The original-reference local ablation in Table 7 supplies the separate in-domain evidence.

The reduced scene18 EKF sensitivity matrix uses nominal coordinates at 0/±30 ms and common +8 cm plus both direction polarities at zero timestamp injection. Direction-response RMS for the difference EKF is 20.255, 20.305 and 20.338 ms at half-windows 0.30, 0.45 and 0.60 s; the completed-pair framewise values are 19.415, 19.447 and 19.508 ms. At 0.60 s, their nominal increment-recovery RMSEs are 0.116 and 0.119 ms. Common displacement still cancels for the difference estimator.

The 0.30 s/+30 ms condition requires a separate support explanation. Its continuous reference interval remains supported, but one frozen observation fails the full-search direction/minimum-speed screen: the minimum sampled axial speed magnitude falls to 0.032754 m/s. The initial sensitivity protocol used that profile screen as a prerequisite for replay, so the primary branch retains a missing +30 ms result and no pooled ±30 ms score. A separately recorded auxiliary replay then applies the original EKF's actual-query support policy to the same 32 observations and 16 endpoints. All 336 logged queries are supported, yielding pooled recovery RMSEs of 0.287 ms for the difference EKF and 0.571 ms for the framewise comparator. These auxiliary values do not replace the primary missing entry or imply that the profile support gate passed. Full-search profile validity and actual EKF update support are distinct properties.



Table S7 reports the separate joint clock-model ablation.

%% Table Caption **Table S7.** Joint clock-model ablation on the fixed G18-C/right observations at the original 0.45 s reference half-window. All values are in ms. Common response uses +8 cm only; direction response pools both polarities; recovery pools nominal-coordinate ±30 ms. The deterministic branch jointly removes initial drift uncertainty and both process densities.

| Clock model | Estimator | Common RMS | Direction RMS | Recovery RMSE |
|:---|:---|:---|:---|:---|
| Stochastic | Difference | 0.000 | 20.305 | 0.177 |
| Stochastic | Framewise | 11.442 | 19.447 | 0.167 |
| Deterministic | Difference | 0.000 | 20.248 | 0.204 |
| Deterministic | Framewise | 1.601 | 20.118 | 0.218 |

In the original-reference deterministic-clock branch, initial drift uncertainty and both process densities are zeroed together. Difference/framewise direction-response RMS values are 20.248/20.118 ms, and nominal increment RMSEs are 0.204/0.218 ms. Difference common-shift response remains numerical zero. The framewise common +8 cm response changes from 11.442 to 1.601 ms. This confirms that the qualitative direction mechanism also occurs without stochastic clock evolution in this conditional replay, while some response magnitudes depend materially on clock dynamics and priors. It neither identifies an isolated drift contribution nor repairs reference or overlapping-interval covariance.



Figure S7 summarizes the reference and clock-model sensitivity.

![Reference and clock model sensitivity](figures/figure_6_reference_clock.png){width=13.6cm}

%% Image Caption **Figure S7.** Fixed-observation sensitivity on G18-C/right. Reference half-window affects the nominal projected information. Direction-displacement response uses identical endpoints. The deterministic-clock comparison changes three clock-state and process settings jointly. The primary 0.30 s/+30 ms replay is unevaluable under the fixed-support screen.

A separate reference-epoch check uses the raw C16 point-time field retained for each extracted target cluster. Using its median relative to the frame header moves the paired EKF terminal estimate from 187.75 to 159.88 ms in recording 08 and from 94.21 to 72.94 ms in recording 09 on the archived 36 and 13 pairs. The recorded coordinates and comparisons at each terminal epoch are fixed. The point field is consistent with the archived scan-start convention and its values range approximately 9–39 ms for these clusters. Seven 08 pairs and one 09 pair lose eligibility under the changed reference, and the fixed-pair replay retains them for sensitivity analysis. On separate prefit common profile supports of 175 and 77 observations, the target-epoch direction-centre diagnostic remains 118.61 and 104.60 ms, respectively. The cluster median time assigns one epoch to the extracted position. It does not deskew the cluster or imply that its coordinate-wise median and median time describe the same detected point. The C16 point-time field is relative to the estimated scan start. The ARS408 stamp is consistent with the decoder’s host-estimated object-cycle boundary. The complete deployed-driver provenance and a physical acquisition-time witness are unavailable, so the two branches quantify sensitivity to the assumed epoch convention.

Figure S8 shows how the estimates respond at each of the 36 and 13 fixed completion epochs when using the target-point-time reference. Both shift polarities are measured relative to zero spatial displacement at zero injected timestamp shift.

![Fixed-pair spatial response for recordings 08 and 09](figures/figure_7_08_09_response.png){width=16.5cm}

%% Image Caption **Figure S8.** Displacement response on recordings 08 and 09 using target-point timing and archived sets of 36 and 13 pairs. Each trace gives the change from the same estimator’s undisplaced output at a completed-pair epoch. The applied common and direction-changing position shifts have amplitudes of ±8 cm. Both estimators use the same completed observations at each epoch. The figure reports perturbation responses of the offset estimate.

# S8. Dependence audit and uncertainty limits

The 16 public scene18 pair intervals all overlap: all 120 pairwise interval comparisons have positive intersection, and the 16-way common intersection lasts 12.700517 s. A maximum interval-disjoint subset contains only one pair. Recording 08 has 225 overlapping interval comparisons out of 630, maximum concurrent interval count 15 and maximum interval-disjoint count three; the corresponding 09 values are 38/78, eight and two. No endpoint is reused in any of those pair sets. Pair residuals can therefore be dependent even with distinct endpoints. The 16 scene18 completion epochs share overlapping intervals, so treating them as 16 independent acquisitions would overstate the evidence. Its profile support occupies only four 1 s bins.



Table S8 quantifies interval overlap without equating unique endpoints with independent measurements.

%% Table Caption **Table S8.** Pair-interval overlap without observation reuse. These are dependence descriptors, not effective sample sizes or independent experimental repeats.

| Recording | Pairs | Reused endpoints | Overlapping interval pairs | Maximum concurrent | Maximum disjoint |
|:---|:--|:---|:----|:---|:---|
| 08 | 36 | 0 | 225 / 630 | 15 | 3 |
| 09 | 13 | 0 | 38 / 78 | 8 | 2 |
| G18-C / right | 16 | 0 | 120 / 120 | 16 | 1 |

At the nominal zero-offset/zero-drift linearization on scene18/right, the trace ratio of the implemented long-pair process term in Equation (9) of the main text to its base measurement covariance ranges from 0.000774 to 0.001053. This describes the numerical scale of that specific approximation, not the size of omitted shared-reference uncertainty, omitted cross-covariances, or a covariance-consistency certificate. No endpoint-level independent-sample significance test is used.

# S9. Displacement and direction-centre controls

Figure S9 shows the known-offset displacement control from Section 4.1 of the manuscript. Figure S10 shows the same-point comparison of projected timing information from Section 4.5.

![Known-offset shared-displacement control for three filters](figures/prior_common_shift_en.png){width=16cm}

%% Image Caption **Figure S9.** Terminal RMSE in the known-offset displacement control in Section 4.1. The filters use the same 500 noise realizations, with a planted +30 ms offset and outbound and return speeds of 1.2 and 1.8 m s⁻¹. The ±8 cm results pool mean-square errors over both signs before taking the square root. The augmented framewise filter uses a translation prior with a standard deviation of 0.30 m per axis.

![Same-point direction-centre ablation for in-house and public recordings](figures/prior_direction_ablation_en.png){width=16cm}

%% Image Caption **Figure S10.** Projected timing information before and after adding the direction-centre column at the same admissible geometry point in Table 7. The horizontal axis shows information in s⁻² on a log scale. Each percentage is relative to the geometry model in the same row. The observations, robust weights and other settings are fixed within each row.

# S10. Speed terms on the strictly opposite vehicle pairs

Figure S11 plots the speed terms from Section 2.2 for the recorded pair schedules. For the original pairing rule in Section 4.12.1, the centred speed-sum term is larger in the primary variable-speed schedule than in the near-constant schedule. The speed-difference term describes information available from the pair means in the stated scalar model.

![Speed sums and differences on the strictly opposite fixed pairs](figures/pair_speed_terms_en.png){width=16.4cm}

%% Image Caption **Figure S11.** Speed terms on the strictly opposite subset of the archived fixed vehicle pairs under the original rule. Panel (a) shows $S=u+w$ and $D=u-w$ for each pair. Here $u$ and $w$ are the outward and return speed magnitudes along the fitted LiDAR motion axis. The near-constant, primary variable-speed and faster schedules contribute 37, 108 and 49 pairs. One near-constant and two primary variable-speed pairs have the same projected direction at both endpoints and are excluded. Panel (b) gives the centred sums of squares for each term across the respective pairs, before noise weighting. These are the scalar-model terms in Section 2.2. The longitudinal local scale in Section 4.12.1 also projects clock drift and uses a separate coordinate and weighting.
