# Archived reference and clock sensitivity

The numeric exports retain the fixed-observation reference/clock branches for
Supplementary Analysis S7 and the pair-interval and process-scale audits for S8.
The CSV files are copied from the archived analysis. The JSON file keeps the
numerical results and omits local provenance paths. Historical fit status fields
are retained as context for those archived runs. Current Table 6 presents selected
fit flags and the continuous scale. The compact archive provides the archived
results for S7 and S8, and the standard entry point starts from these results for
these checks.

The independent AIRY board-point replay remains available using
`python -B run_all.py --point-timing-only`. The preceding 08/09 C16 target-time
checks have their own preserved inputs under
`outputs/mst_review_20261117/reviewer_replay/`.
