# Reproducing the added Measurement figures

| Label | Figure | Archived input |
| --- | --- | --- |
| Figure S11 | Speed sums and differences on strictly opposite AIRY–ARS408 pairs | `figure_data/field_pair_speeds.csv` |
| Figure S5 | Field association and round-trip selection sensitivity | `figure_data/field_stability.json` |
| Figure S6 | Local timing scale and terminal error in known-offset simulations | `figure_data/simulation_scale_trials.csv` and `figure_data/simulation_scale_summary.csv` |

Figure S11 uses the archived original pairing schedules, with 37, 108 and 49 strictly opposite pairs after checking the signs on the fitted LiDAR motion axis. The centred sums of squares are unweighted scalar-model terms. The pair-speed input can be regenerated with `figure_data/prepare_pair_speeds.py <path-to-clean-reviewer-run>` from an unpacked and successfully replayed reviewer archive.

Figure S5 uses the published fixed-frame association checks and round-trip omissions. Its offsets are fitted candidates on the replay clock convention. Figure S6 uses 119 evaluable simulations with known planted offsets and retains the failed trial in the scheduled count.

Run the following plotting commands from this `added_figures/` directory. The optional speed-data re-export is available as `python -B figure_data/prepare_pair_speeds.py`. Its default archive is this release.

The plots were built with Python 3.12, NumPy 2.5.4 and Matplotlib 3.11.2. The English figures use Times New Roman and the Chinese figures use Microsoft YaHei, with Noto Sans CJK SC as a fallback.

```sh
python -m pip install numpy==2.5.4 matplotlib==3.11.2
python figures/gen_fig_17_pair_speeds.py
python figures/gen_fig_s5_association.py
python figures/gen_fig_s6_simulation.py
```

The `figures` folder contains English and Chinese vector PDFs and 300 dpi PNGs.
